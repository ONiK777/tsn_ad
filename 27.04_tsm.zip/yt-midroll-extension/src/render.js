// ─── РЕНДЕР ──────────────────────────────────────────────────────────────────
var offscreenCanvas = null;
var lastRenderSignature = null;
var lastStatsAdCount = null;

function getWaveformView(duration) {
  const safeDuration = Math.max(0, Number(duration) || 0);
  const zoom = Math.max(1, Math.min(16, Number(state.waveformZoom) || 1));
  const viewDuration = safeDuration > 0 ? safeDuration / zoom : 0;
  const maxStart = Math.max(0, safeDuration - viewDuration);
  const start = Math.max(0, Math.min(Number(state.waveformOffsetSec) || 0, maxStart));

  state.waveformZoom = zoom;
  state.waveformOffsetSec = start;

  return {
    zoom,
    start,
    end: start + viewDuration,
    viewDuration,
    maxStart
  };
}

function showStopButton(show) {
  const insertBtn = document.getElementById('mra-insert');
  let stopBtn = document.getElementById('mra-stop');

  if (show) {
    if (insertBtn) insertBtn.style.display = 'none';
    if (!stopBtn && insertBtn && insertBtn.parentNode) {
      stopBtn = document.createElement('button');
      stopBtn.id = 'mra-stop';
      stopBtn.textContent = '⛔ ЗУПИНИТИ';
      stopBtn.style.cssText = 'width:100%;padding:10px;border:none;border-radius:4px;cursor:pointer;font-size:13px;font-weight:900;text-transform:uppercase;letter-spacing:0.5px;transition:all .2s;margin-bottom:6px;background:#ff6b6b;color:#fff;';
      stopBtn.addEventListener('click', () => { state.insertAbort = true; });
      insertBtn.parentNode.insertBefore(stopBtn, insertBtn.nextSibling);
    }
    if (stopBtn) stopBtn.style.display = '';
  } else {
    if (stopBtn) stopBtn.style.display = 'none';
    if (insertBtn) insertBtn.style.display = '';
  }
}

function renderSelectedList() {
  const list = document.getElementById('mra-list');
  const stats = document.getElementById('mra-stats');
  if (!list) return;

  if (stats && state.waveformData && state.waveformData.duration > 0) {
    stats.style.display = 'block';

    const duration = state.waveformData.duration;

    // СТАНДАРТ ТСН: хронометраж ділимо на 2 (1 реклама кожні 2 хв / 120 сек)
    let idealAds = Math.floor(duration / 120);

    // Ютуб дозволяє мідроли тільки для відео від 8 хвилин (480 сек)
    if (duration < 480) {
      idealAds = 0;
    } else if (idealAds < 1) {
      idealAds = 1;
    }

    const actualAds = state.selected.length;

    let ratioEmoji = '✅ Люкс';
    let ratioColor = '#06d6a0';

    if (duration < 480) {
      ratioEmoji = '⏳ До 8 хв (Без реклами)';
      ratioColor = '#888888';
    } else if (actualAds === 0) {
      ratioEmoji = '❌ Немає';
      ratioColor = '#ff6b6b';
    } else if (actualAds < idealAds) {
      // Суворе правило: якщо менше ділення на 2 — значить погано (мало)
      ratioEmoji = '⚠️ Малувато';
      ratioColor = '#ffd166';
    } else if (actualAds > idealAds + 2) {
      // Якщо напхали на 3 реклами більше ідеалу
      ratioEmoji = '🔥 Густо';
      ratioColor = '#ff6b6b';
    }

    const min = Math.floor(duration / 60);
    const sec = Math.floor(duration % 60);
    const durStr = `${String(min).padStart(2, '0')}:${String(sec).padStart(2, '0')}`;

    stats.innerHTML = `
      <span style="color:#888;" title="Хронометраж відео">⏱️ ${durStr}</span>
      &nbsp;|&nbsp;
      <span style="color:#ccc;">Міт.: <b style="color:#fff">${actualAds}</b> <span style="font-size:10px;color:#666;" title="Ідеальна кількість реклам для такого хронометражу">(ідеал ~${idealAds})</span></span> 
      &nbsp;|&nbsp;
      <span style="color:${ratioColor};" title="Статус щільності реклами">${ratioEmoji}</span>
    `;

    // ── Постійне пульсування для проблемних статусів ──
    const isGusto = ratioEmoji.includes('Густо');
    const isMaluv = ratioEmoji.includes('Малувато');

    // Знімаємо всі попередні анімаційні класи
    stats.classList.remove('mra-pulse-red', 'mra-pulse-yellow');

    if (isGusto) {
      // 🔥 Густо — постійне червоне пульсування (не дратує, просто нагадує)
      stats.classList.add('mra-pulse-red');
    } else if (isMaluv) {
      // ⚠️ Малувато — постійне жовте пульсування
      stats.classList.add('mra-pulse-yellow');
    } else {
      // ✅ Люкс — одноразовий подвійний спалах через animate()
      if (lastStatsAdCount !== actualAds) {
        try {
          stats.animate([
            { boxShadow: '0 0 0px transparent', borderColor: '#333' },
            { boxShadow: `0 0 12px ${ratioColor}`, borderColor: ratioColor, offset: 0.25 },
            { boxShadow: '0 0 0px transparent', borderColor: '#333', offset: 0.5 },
            { boxShadow: `0 0 12px ${ratioColor}`, borderColor: ratioColor, offset: 0.75 },
            { boxShadow: '0 0 0px transparent', borderColor: '#333' }
          ], { duration: 1200, easing: 'ease-in-out' });
        } catch (e) { }
      }
    }

    lastStatsAdCount = actualAds;
  } else if (stats) {
    stats.classList.remove('mra-pulse-red', 'mra-pulse-yellow');
    stats.style.display = 'none';
  }

  list.innerHTML = '';
  state.selected.forEach((s, i) => {
    const item = document.createElement('div');
    item.style.cssText = 'display:flex;align-items:center;gap:6px;margin:3px 0;';

    const numSpan = document.createElement('span');
    numSpan.style.cssText = 'color:#c91c1c;font-weight:bold;';

    if (s.inserted) {
      numSpan.textContent = '✅';
      numSpan.style.color = '#06d6a0'; // зеленим
    } else {
      numSpan.textContent = `${i + 1}.`;
    }

    const timeSpan = document.createElement('span');
    timeSpan.style.color = s.inserted ? '#888' : '#e0e0e0';
    timeSpan.style.textDecoration = s.inserted ? 'line-through' : 'none';
    timeSpan.textContent = s.timecode;

    const durSpan = document.createElement('span');
    const durationSec = Number(s.duration_sec) || 0;
    const durationLabel = durationSec > 0 ? `${durationSec.toFixed(1).replace('.0', '')}с` : '';
    durSpan.style.cssText = 'color:#888;font-size:11px;';

    if (durationSec > 0) {
      const quality = Number(s.quality_score);
      const qualityLabel = Number.isFinite(quality) ? ` · ${Math.round(quality * 100)}%` : '';
      durSpan.textContent = `(пауза ${durationLabel}${qualityLabel})`;
    } else {
      durSpan.textContent = '';
    }

    item.appendChild(numSpan);
    item.appendChild(timeSpan);
    item.appendChild(durSpan);

    if (s.manual) {
      const badge = document.createElement('span');
      badge.style.cssText = 'color:#ffffff;font-size:10px;';
      badge.title = 'Вручну додано';
      badge.textContent = '✋';
      item.appendChild(badge);
    }

    const delBtn = document.createElement('button');
    delBtn.style.cssText = 'margin-left:auto;background:none;border:none;color:#ff6b6b;cursor:pointer;font-size:14px;padding:0 4px;';
    delBtn.textContent = '✕';
    delBtn.addEventListener('click', () => {
      state.selected.splice(i, 1);
      renderSelectedList();
      renderWaveform();
    });
    item.appendChild(delBtn);

    list.appendChild(item);
  });
  const insertBtn = document.getElementById('mra-insert');
  if (insertBtn) insertBtn.disabled = state.selected.length === 0;
}

// ─── ВІЗУАЛІЗАЦІЯ ВЕЙВФОРМИ ───────────────────────────────────────────────────

function renderWaveform() {
  const canvas = document.getElementById('mra-waveform');
  const section = document.getElementById('mra-waveform-section');

  if (!canvas || !state.waveformData) {
    if (section) section.style.display = 'none';
    return;
  }

  if (section) section.style.display = '';

  const dpr = window.devicePixelRatio || 1;
  const displayW = canvas.clientWidth;
  const displayH = canvas.clientHeight;
  if (canvas.width !== displayW * dpr || canvas.height !== displayH * dpr) {
    canvas.width = displayW * dpr;
    canvas.height = displayH * dpr;
    offscreenCanvas = null;
    lastRenderSignature = null;
  }

  const { envelope, smoothed, duration, totalBlocks, threshold } = state.waveformData;

  const ctx = canvas.getContext('2d', { alpha: false });
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  const w = displayW;
  const h = displayH;
  const view = getWaveformView(duration);
  const timeToX = (seconds) => ((seconds - view.start) / view.viewDuration) * w;
  const isTimeVisible = (seconds) => seconds >= view.start && seconds <= view.end;

  const silenceSignature = state.silences
    .map(s => `${s.seconds}:${s.duration_sec}`)
    .join('|');
  const signature = `${totalBlocks}_${threshold}_${view.zoom}_${view.start.toFixed(2)}_${silenceSignature}`;
  const needsRedraw = lastRenderSignature !== signature;

  // ── Відмальовка статичної частини (бари + дзеркало) ──
  if (needsRedraw) {
    if (!offscreenCanvas) {
      offscreenCanvas = document.createElement('canvas');
      offscreenCanvas.width = w * dpr;
      offscreenCanvas.height = h * dpr;
    }

    const offCtx = offscreenCanvas.getContext('2d', { alpha: false });
    offCtx.setTransform(dpr, 0, 0, dpr, 0, 0);

    // Глибокий фон з ледь помітним віньєтуванням
    const bgGrad = offCtx.createLinearGradient(0, 0, 0, h);
    bgGrad.addColorStop(0, '#0C0C10');
    bgGrad.addColorStop(0.5, '#111115');
    bgGrad.addColorStop(1, '#0C0C10');
    offCtx.fillStyle = bgGrad;
    offCtx.fillRect(0, 0, w, h);

    const visualEnvelope = envelope || smoothed;
    const maxAmp = arrayMax(visualEnvelope);
    if (maxAmp <= 0) return;

    const centerY = Math.round(h * 0.46);

    // Тонка горизонтальна лінія-вісь
    offCtx.fillStyle = 'rgba(255, 255, 255, 0.04)';
    offCtx.fillRect(0, centerY, w, 1);

    // ── Реальна вейвформа: тільки амплітуда звуку, без зеленого фону пауз ──
    const barW = 2;
    const step = 3;
    const numBars = Math.floor(w / step);

    const maxBarH = h * 0.38;
    const barGrad = offCtx.createLinearGradient(0, centerY - maxBarH, 0, centerY);
    barGrad.addColorStop(0, 'rgba(255, 255, 255, 0.42)');
    barGrad.addColorStop(0.45, 'rgba(255, 255, 255, 0.9)');
    barGrad.addColorStop(1, 'rgba(255, 255, 255, 0.62)');

    for (let i = 0; i < numBars; i++) {
      const timeSec = view.start + (i / Math.max(numBars, 1)) * view.viewDuration;
      const blockIdx = Math.floor((timeSec / duration) * totalBlocks);
      if (blockIdx >= totalBlocks) break;

      const amp = visualEnvelope[blockIdx];
      const normalizedAmp = amp / maxAmp;

      const barH = Math.max(normalizedAmp * maxBarH, 1);
      const barX = i * step;

      offCtx.fillStyle = barGrad;
      offCtx.fillRect(barX, centerY - barH, barW, barH);

      const mirrorH = barH * 0.45;
      offCtx.fillStyle = 'rgba(255, 255, 255, 0.12)';
      offCtx.fillRect(barX, centerY + 1, barW, mirrorH);
    }

    lastRenderSignature = signature;
  }

  // ── Копіюємо на екран ──
  if (offscreenCanvas) {
    ctx.drawImage(offscreenCanvas, 0, 0, w, h);
  } else {
    ctx.fillStyle = '#0C0C10';
    ctx.fillRect(0, 0, w, h);
  }

  // ── Смислові зони ──
  if (state.selected.length > 0) {
    const idealGap = CONFIG.autoGap
      ? (state.waveformData.duration < CONFIG.shortVideoCutoff ? CONFIG.shortVideoGapSec : CONFIG.longVideoGapSec)
      : CONFIG.minGapSec;

    const zoneBoundaries = [0, ...state.selected.map(s => s.seconds), duration];

    for (let z = 0; z < zoneBoundaries.length - 1; z++) {
      const gapSec = zoneBoundaries[z + 1] - zoneBoundaries[z];
      const visibleStart = Math.max(zoneBoundaries[z], view.start);
      const visibleEnd = Math.min(zoneBoundaries[z + 1], view.end);
      if (visibleEnd <= visibleStart) continue;

      const x1 = timeToX(visibleStart);
      const x2 = timeToX(visibleEnd);
      const zoneW = x2 - x1;

      let solidColor, colorStr;
      const ratio = gapSec / idealGap;
      if (ratio < 0.5) { solidColor = '#E52E2E'; colorStr = '229,46,46'; }
      else if (ratio < 0.8) { solidColor = '#FBBF24'; colorStr = '251,191,36'; }
      else if (ratio <= 1.3) { solidColor = '#10B981'; colorStr = '16,185,129'; }
      else { solidColor = '#38BDF8'; colorStr = '56,189,248'; }

      // Ледь помітний тінт на всю зону
      ctx.fillStyle = `rgba(${colorStr}, 0.05)`;
      ctx.fillRect(x1, 0, zoneW, h - 4);

      // Кольорова стрічка знизу (3px)
      ctx.fillStyle = solidColor;
      ctx.globalAlpha = 0.75;
      ctx.fillRect(x1 + 1, h - 3, Math.max(zoneW - 2, 0), 3);
      ctx.globalAlpha = 1.0;

      // Хронометраж (тільки якщо достатньо місця)
      if (zoneW > 42) {
        const gapMin = Math.floor(gapSec / 60);
        const gapRemSec = Math.floor(gapSec % 60);
        const gapLabel = gapMin > 0
          ? `${gapMin}:${String(gapRemSec).padStart(2, '0')}`
          : `${Math.floor(gapSec)}с`;

        ctx.font = '500 9px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
        const tw = ctx.measureText(gapLabel).width;

        // Розташування: знизу, трохи над стрічкою
        const labelY = h - 8;
        const labelX = x1 + zoneW / 2 - tw / 2;

        ctx.fillStyle = 'rgba(255,255,255,0.5)';
        ctx.fillText(gapLabel, labelX, labelY);
      }
    }
  }

  // ── Жовті вертикалі: паузи, куди ще можна поставити вручну ──
  state.silences.forEach(s => {
    const alreadySelected = state.selected.some(sel => Math.abs(sel.seconds - s.seconds) < 1);
    if (alreadySelected) return;
    if (!isTimeVisible(s.seconds)) return;

    const sx = timeToX(s.seconds);
    const quality = Math.max(0, Math.min(1, Number(s.quality_score) || 0.45));
    const lineAlpha = 0.38 + quality * 0.52;
    const glowAlpha = 0.25 + quality * 0.5;
    const lineWidth = 1 + quality * 0.7;
    const dashOn = quality >= 0.78 ? 6 : 4;
    const dashOff = quality >= 0.55 ? 3 : 4;

    ctx.save();
    ctx.strokeStyle = `rgba(251, 191, 36, ${lineAlpha.toFixed(2)})`;
    ctx.lineWidth = lineWidth;
    ctx.shadowColor = `rgba(251, 191, 36, ${glowAlpha.toFixed(2)})`;
    ctx.shadowBlur = 4 + quality * 5;
    ctx.setLineDash([dashOn, dashOff]);
    ctx.beginPath();
    ctx.moveTo(sx, 5);
    ctx.lineTo(sx, h - 10);
    ctx.stroke();
    ctx.setLineDash([]);

    ctx.fillStyle = `rgba(251, 191, 36, ${Math.min(1, lineAlpha + 0.1).toFixed(2)})`;
    ctx.beginPath();
    ctx.arc(sx, 6, 1.8 + quality * 0.8, 0, Math.PI * 2);
    ctx.fill();

    ctx.globalAlpha = Math.min(1, 0.45 + quality * 0.45);
    ctx.fillRect(sx - 4, h - 9, 8, 2);
    ctx.restore();
  });

  // ── Маркери ──
  state.selected.forEach((s, i) => {
    if (!isTimeVisible(s.seconds)) return;

    const x = timeToX(s.seconds);
    const isManual = s.manual;
    const color = isManual ? '#FBBF24' : '#E52E2E';

    // Лінія з неоновим glow
    ctx.strokeStyle = color;
    ctx.lineWidth = 1;
    ctx.shadowColor = color;
    ctx.shadowBlur = 4;

    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, h - 4);
    ctx.stroke();
    ctx.shadowBlur = 0;

    // Компактний бейдж зверху
    const label = isManual ? `✋${i + 1}` : `${i + 1}`;
    ctx.font = '700 8px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
    const tw = ctx.measureText(label).width;
    const badgeW = tw + 6;
    const badgeH = 13;
    const badgeX = x - badgeW / 2;
    const badgeY = 1;

    // Фон бейджу
    ctx.fillStyle = color;
    ctx.beginPath();
    if (ctx.roundRect) ctx.roundRect(badgeX, badgeY, badgeW, badgeH, 3);
    else ctx.fillRect(badgeX, badgeY, badgeW, badgeH);
    ctx.fill();

    // Текст бейджу
    ctx.fillStyle = isManual ? '#000' : '#fff';
    ctx.textBaseline = 'middle';
    ctx.fillText(label, badgeX + 3, badgeY + badgeH / 2 + 0.5);
    ctx.textBaseline = 'alphabetic';
  });

  // ── Часові мітки ──
  ctx.fillStyle = '#52525B';
  ctx.font = '500 8px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
  ctx.shadowBlur = 0;
  const timeMarks = 6;
  for (let i = 0; i <= timeMarks; i++) {
    const x = (i / timeMarks) * w;
    const timeSec = view.start + (i / timeMarks) * view.viewDuration;
    const m = Math.floor(timeSec / 60);
    const s = Math.floor(timeSec % 60);
    const timeStr = s > 0 ? `${m}:${String(s).padStart(2, '0')}` : `${m}m`;

    let textX = x + 2;
    if (i === timeMarks) textX = x - ctx.measureText(timeStr).width - 2;
    else if (i !== 0) textX = x - ctx.measureText(timeStr).width / 2;

    ctx.fillText(timeStr, textX, h - 7);
  }

  if (typeof updateWaveformZoomUI === 'function') updateWaveformZoomUI();
  if (needsRedraw) log('Вейвформа: повний рендер', 'info');
}
