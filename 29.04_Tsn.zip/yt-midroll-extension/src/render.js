// ─── РЕНДЕР ──────────────────────────────────────────────────────────────────
var offscreenCanvas = null;
var lastRenderSignature = null;
var lastStatsAdCount = null;

function getWaveformView(duration) {
  const safeDuration = Math.max(0, Number(duration) || 0);
  const zoom = Math.max(1, Math.min(16, Number(state.waveformZoom) || 1));
  const viewDuration = safeDuration > 0 ? safeDuration / zoom : 0;
  const maxStart = Math.max(0, safeDuration - viewDuration);
  const start = Math.max(0, Math.min(Number(state.waveformOffsetSec) || 0, maxStart));

  state.waveformZoom = zoom;
  state.waveformOffsetSec = start;

  return {
    zoom,
    start,
    end: start + viewDuration,
    viewDuration,
    maxStart
  };
}

function showStopButton(show) {
  const insertBtn = document.getElementById('mra-insert');
  let stopBtn = document.getElementById('mra-stop');

  if (show) {
    if (insertBtn) insertBtn.style.display = 'none';
    if (!stopBtn && insertBtn && insertBtn.parentNode) {
      stopBtn = document.createElement('button');
      stopBtn.id = 'mra-stop';
      stopBtn.textContent = '⛔ ЗУПИНИТИ';
      stopBtn.style.cssText = 'width:100%;padding:10px;border:none;border-radius:4px;cursor:pointer;font-size:13px;font-weight:900;text-transform:uppercase;letter-spacing:0.5px;transition:all .2s;margin-bottom:6px;background:#ff6b6b;color:#fff;';
      stopBtn.addEventListener('click', () => { state.insertAbort = true; });
      insertBtn.parentNode.insertBefore(stopBtn, insertBtn.nextSibling);
    }
    if (stopBtn) stopBtn.style.display = '';
  } else {
    if (stopBtn) stopBtn.style.display = 'none';
    if (insertBtn) insertBtn.style.display = '';
  }
}

function renderSelectedList() {
  const list = document.getElementById('mra-list');
  const stats = document.getElementById('mra-stats');
  if (!list) return;

  if (stats && state.waveformData && state.waveformData.duration > 0) {
    stats.style.display = 'block';

    const duration = state.waveformData.duration;

    // СТАНДАРТ ТСН: хронометраж ділимо на 2 (1 реклама кожні 2 хв / 120 сек)
    let idealAds = Math.floor(duration / 120);

    // Ютуб дозволяє мідроли тільки для відео від 8 хвилин (480 сек)
    if (duration < 480) {
      idealAds = 0;
    } else if (idealAds < 1) {
      idealAds = 1;
    }

    const actualAds = state.selected.length;

    let ratioEmoji = '✅ Люкс';
    let ratioColor = '#06d6a0';

    if (duration < 480) {
      ratioEmoji = '⏳ До 8 хв (Без реклами)';
      ratioColor = '#888888';
    } else if (actualAds === 0) {
      ratioEmoji = '❌ Немає';
      ratioColor = '#ff6b6b';
    } else if (actualAds < idealAds) {
      // Суворе правило: якщо менше ділення на 2 — значить погано (мало)
      ratioEmoji = '⚠️ Малувато';
      ratioColor = '#ffd166';
    } else if (actualAds > idealAds + 2) {
      // Якщо напхали на 3 реклами більше ідеалу
      ratioEmoji = '🔥 Густо';
      ratioColor = '#ff6b6b';
    }

    const min = Math.floor(duration / 60);
    const sec = Math.floor(duration % 60);
    const durStr = `${String(min).padStart(2, '0')}:${String(sec).padStart(2, '0')}`;

    stats.innerHTML = `
      <span style="color:#888;" title="Хронометраж відео">⏱️ ${durStr}</span>
      &nbsp;|&nbsp;
      <span style="color:#ccc;">Міт.: <b style="color:#fff">${actualAds}</b> <span style="font-size:10px;color:#666;" title="Ідеальна кількість реклам для такого хронометражу">(ідеал ~${idealAds})</span></span> 
      &nbsp;|&nbsp;
      <span style="color:${ratioColor};" title="Статус щільності реклами">${ratioEmoji}</span>
    `;

    // ── Постійне пульсування для проблемних статусів ──
    const isGusto = ratioEmoji.includes('Густо');
    const isMaluv = ratioEmoji.includes('Малувато');

    // Знімаємо всі попередні анімаційні класи
    stats.classList.remove('mra-pulse-red', 'mra-pulse-yellow');

    if (isGusto) {
      // 🔥 Густо — постійне червоне пульсування (не дратує, просто нагадує)
      stats.classList.add('mra-pulse-red');
    } else if (isMaluv) {
      // ⚠️ Малувато — постійне жовте пульсування
      stats.classList.add('mra-pulse-yellow');
    } else {
      // ✅ Люкс — одноразовий подвійний спалах через animate()
      if (lastStatsAdCount !== actualAds) {
        try {
          stats.animate([
            { boxShadow: '0 0 0px transparent', borderColor: '#333' },
            { boxShadow: `0 0 12px ${ratioColor}`, borderColor: ratioColor, offset: 0.25 },
            { boxShadow: '0 0 0px transparent', borderColor: '#333', offset: 0.5 },
            { boxShadow: `0 0 12px ${ratioColor}`, borderColor: ratioColor, offset: 0.75 },
            { boxShadow: '0 0 0px transparent', borderColor: '#333' }
          ], { duration: 1200, easing: 'ease-in-out' });
        } catch (e) { }
      }
    }

    lastStatsAdCount = actualAds;
  } else if (stats) {
    stats.classList.remove('mra-pulse-red', 'mra-pulse-yellow');
    stats.style.display = 'none';
  }

  list.innerHTML = '';
  state.selected.forEach((s, i) => {
    const item = document.createElement('div');
    item.style.cssText = 'display:flex;align-items:center;gap:6px;margin:3px 0;';

    const numSpan = document.createElement('span');
    numSpan.style.cssText = 'color:#c91c1c;font-weight:bold;';

    if (s.inserted) {
      numSpan.textContent = '✅';
      numSpan.style.color = '#06d6a0'; // зеленим
    } else {
      numSpan.textContent = `${i + 1}.`;
    }

    const timeSpan = document.createElement('span');
    timeSpan.style.color = s.inserted ? '#888' : '#e0e0e0';
    timeSpan.style.textDecoration = s.inserted ? 'line-through' : 'none';
    timeSpan.textContent = s.timecode;

    const durSpan = document.createElement('span');
    const durationSec = Number(s.duration_sec) || 0;
    const durationLabel = durationSec > 0 ? `${durationSec.toFixed(1).replace('.0', '')}с` : '';
    durSpan.style.cssText = 'color:#888;font-size:11px;';

    if (durationSec > 0) {
      const quality = Number(s.quality_score);
      const qualityLabel = Number.isFinite(quality) ? ` · ${Math.round(quality * 100)}%` : '';
      durSpan.textContent = `(пауза ${durationLabel}${qualityLabel})`;
    } else {
      durSpan.textContent = '';
    }

    item.appendChild(numSpan);
    item.appendChild(timeSpan);
    item.appendChild(durSpan);

    if (s.manual) {
      const badge = document.createElement('span');
      badge.style.cssText = 'color:#ffffff;font-size:10px;';
      badge.title = 'Вручну додано';
      badge.textContent = '✋';
      item.appendChild(badge);
    }

    const delBtn = document.createElement('button');
    delBtn.style.cssText = 'margin-left:auto;background:none;border:none;color:#ff6b6b;cursor:pointer;font-size:14px;padding:0 4px;';
    delBtn.textContent = '✕';
    delBtn.addEventListener('click', () => {
      state.selected.splice(i, 1);
      renderSelectedList();
      renderWaveform();
    });
    item.appendChild(delBtn);

    list.appendChild(item);
  });
  const insertBtn = document.getElementById('mra-insert');
  if (insertBtn) insertBtn.disabled = state.selected.length === 0;
}

// ─── ВІЗУАЛІЗАЦІЯ ВЕЙВФОРМИ ───────────────────────────────────────────────────

function renderWaveform() {
  const canvas = document.getElementById('mra-waveform');
  const section = document.getElementById('mra-waveform-section');

  if (!canvas || !state.waveformData) {
    if (section) section.style.display = 'none';
    return;
  }

  if (section) section.style.display = '';

  const dpr = window.devicePixelRatio || 1;
  const displayW = canvas.clientWidth;
  const displayH = canvas.clientHeight;
  if (canvas.width !== displayW * dpr || canvas.height !== displayH * dpr) {
    canvas.width = displayW * dpr;
    canvas.height = displayH * dpr;
    offscreenCanvas = null;
    lastRenderSignature = null;
  }

  const { envelope, smoothed, duration, totalBlocks, threshold } = state.waveformData;

  const ctx = canvas.getContext('2d', { alpha: false });
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  const w = displayW;
  const h = displayH;
  const view = getWaveformView(duration);
  const timeToX = (seconds) => ((seconds - view.start) / view.viewDuration) * w;
  const isTimeVisible = (seconds) => seconds >= view.start && seconds <= view.end;
  const drawWaveformSurface = (targetCtx) => {
    const bg = targetCtx.createLinearGradient(0, 0, 0, h);
    bg.addColorStop(0, '#0B0D10');
    bg.addColorStop(0.45, '#11151A');
    bg.addColorStop(1, '#090B0E');
    targetCtx.fillStyle = bg;
    targetCtx.fillRect(0, 0, w, h);

    targetCtx.fillStyle = 'rgba(255, 255, 255, 0.05)';
    targetCtx.fillRect(0, Math.round(h * 0.5), w, 1);
  };

  const silenceSignature = state.silences
    .map(s => `${s.seconds}:${s.duration_sec}`)
    .join('|');
  const signature = `${totalBlocks}_${threshold}_${view.zoom}_${view.start.toFixed(2)}_${silenceSignature}`;
  const needsRedraw = lastRenderSignature !== signature;

  // ── Відмальовка статичної частини (бари + дзеркало) ──
  if (needsRedraw) {
    if (!offscreenCanvas) {
      offscreenCanvas = document.createElement('canvas');
      offscreenCanvas.width = w * dpr;
      offscreenCanvas.height = h * dpr;
    }

    const offCtx = offscreenCanvas.getContext('2d');
    offCtx.setTransform(dpr, 0, 0, dpr, 0, 0);
    offCtx.clearRect(0, 0, w, h);

    const visualEnvelope = envelope || smoothed;
    const peakSamples = [];
    const sampleStep = Math.max(1, Math.floor(visualEnvelope.length / 1800));
    for (let i = 0; i < visualEnvelope.length; i += sampleStep) {
      peakSamples.push(visualEnvelope[i]);
    }
    peakSamples.sort((a, b) => a - b);

    const maxAmp = arrayMax(visualEnvelope);
    const p95Amp = peakSamples.length ? peakSamples[Math.floor(peakSamples.length * 0.95)] : maxAmp;
    const visualMax = Math.max(p95Amp * 1.28, maxAmp * 0.38, 0.000001);
    if (maxAmp <= 0) return;

    const centerY = Math.round(h * 0.5);

    const numBars = Math.max(2, Math.floor(w));

    const maxBarH = h * 0.42;
    const mirrorRatio = 0.78;
    const points = [];

    for (let i = 0; i < numBars; i++) {
      const rangeStartSec = view.start + (i / Math.max(numBars, 1)) * view.viewDuration;
      const rangeEndSec = view.start + ((i + 1) / Math.max(numBars, 1)) * view.viewDuration;
      const blockStart = Math.max(0, Math.floor((rangeStartSec / duration) * totalBlocks));
      const blockEnd = Math.min(totalBlocks - 1, Math.max(blockStart, Math.ceil((rangeEndSec / duration) * totalBlocks)));

      let amp = 0;
      let avg = 0;
      let samples = 0;
      for (let b = blockStart; b <= blockEnd; b++) {
        if (visualEnvelope[b] > amp) amp = visualEnvelope[b];
        avg += visualEnvelope[b];
        samples++;
      }
      avg = samples > 0 ? avg / samples : amp;
      const shapedAmp = amp * 0.82 + avg * 0.18;
      const normalizedAmp = Math.pow(Math.min(1, shapedAmp / visualMax), 0.74);

      const topH = Math.max(normalizedAmp * maxBarH, 1);
      const bottomH = Math.max(topH * mirrorRatio, 1);
      points.push({ x: i, topH, bottomH });
    }

    const mirrorGrad = offCtx.createLinearGradient(0, centerY, 0, centerY + maxBarH);
    mirrorGrad.addColorStop(0, 'rgba(168, 178, 183, 0.28)');
    mirrorGrad.addColorStop(1, 'rgba(168, 178, 183, 0.05)');
    offCtx.fillStyle = mirrorGrad;
    offCtx.beginPath();
    offCtx.moveTo(0, centerY);
    points.forEach(p => offCtx.lineTo(p.x, centerY + p.bottomH));
    offCtx.lineTo(w, centerY);
    offCtx.closePath();
    offCtx.fill();

    const waveGrad = offCtx.createLinearGradient(0, centerY - maxBarH, 0, centerY);
    waveGrad.addColorStop(0, 'rgba(255, 255, 255, 0.52)');
    waveGrad.addColorStop(0.34, 'rgba(250, 252, 253, 0.96)');
    waveGrad.addColorStop(1, 'rgba(214, 222, 224, 0.78)');
    offCtx.fillStyle = waveGrad;
    offCtx.beginPath();
    offCtx.moveTo(0, centerY);
    points.forEach(p => offCtx.lineTo(p.x, centerY - p.topH));
    offCtx.lineTo(w, centerY);
    offCtx.closePath();
    offCtx.fill();

    offCtx.strokeStyle = 'rgba(255, 255, 255, 0.22)';
    offCtx.lineWidth = 0.6;
    for (let i = 0; i < points.length; i += 3) {
      const p = points[i];
      offCtx.beginPath();
      offCtx.moveTo(p.x + 0.5, centerY - p.topH);
      offCtx.lineTo(p.x + 0.5, centerY + p.bottomH);
      offCtx.stroke();
    }

    offCtx.fillStyle = 'rgba(255, 255, 255, 0.08)';
    offCtx.fillRect(0, centerY, w, 1);

    lastRenderSignature = signature;
  }

  // ── Копіюємо на екран ──
  drawWaveformSurface(ctx);

  // ── Смислові зони ──
  if (state.selected.length > 0) {
    const idealGap = CONFIG.autoGap
      ? (state.waveformData.duration < CONFIG.shortVideoCutoff ? CONFIG.shortVideoGapSec : CONFIG.longVideoGapSec)
      : CONFIG.minGapSec;

    const zoneBoundaries = [0, ...state.selected.map(s => s.seconds), duration];

    for (let z = 0; z < zoneBoundaries.length - 1; z++) {
      const gapSec = zoneBoundaries[z + 1] - zoneBoundaries[z];
      const visibleStart = Math.max(zoneBoundaries[z], view.start);
      const visibleEnd = Math.min(zoneBoundaries[z + 1], view.end);
      if (visibleEnd <= visibleStart) continue;

      const x1 = timeToX(visibleStart);
      const x2 = timeToX(visibleEnd);
      const zoneW = x2 - x1;

      let solidColor, colorStr, zoneAlpha;
      const ratio = gapSec / idealGap;
      if (ratio < 0.5) { solidColor = '#E52E2E'; colorStr = '229,46,46'; zoneAlpha = 0.07; }
      else if (ratio < 0.8) { solidColor = '#FBBF24'; colorStr = '251,191,36'; zoneAlpha = 0.11; }
      else if (ratio <= 1.3) { solidColor = '#10B981'; colorStr = '16,185,129'; zoneAlpha = 0.09; }
      else { solidColor = '#60A5FA'; colorStr = '96,165,250'; zoneAlpha = 0.09; }

      // Кольоровий сегмент між мітками: підказує ритм, але не ховає саму вейвформу.
      ctx.fillStyle = `rgba(${colorStr}, ${zoneAlpha})`;
      ctx.fillRect(x1, 0, zoneW, h - 4);

      ctx.fillStyle = `rgba(${colorStr}, ${Math.min(0.22, zoneAlpha + 0.06)})`;
      ctx.fillRect(x1, 0, 1, h - 4);
      ctx.fillRect(x2 - 1, 0, 1, h - 4);

      // Кольорова стрічка знизу (3px)
      ctx.fillStyle = solidColor;
      ctx.globalAlpha = 0.38;
      ctx.fillRect(x1 + 1, h - 3, Math.max(zoneW - 2, 0), 3);
      ctx.globalAlpha = 1.0;

    }
  }

  if (offscreenCanvas) {
    ctx.drawImage(offscreenCanvas, 0, 0, w, h);
  }

  if (state.selected.length > 0) {
    const idealGap = CONFIG.autoGap
      ? (state.waveformData.duration < CONFIG.shortVideoCutoff ? CONFIG.shortVideoGapSec : CONFIG.longVideoGapSec)
      : CONFIG.minGapSec;
    const zoneBoundaries = [0, ...state.selected.map(s => s.seconds), duration];

    for (let z = 0; z < zoneBoundaries.length - 1; z++) {
      const gapSec = zoneBoundaries[z + 1] - zoneBoundaries[z];
      const visibleStart = Math.max(zoneBoundaries[z], view.start);
      const visibleEnd = Math.min(zoneBoundaries[z + 1], view.end);
      if (visibleEnd <= visibleStart) continue;

      const x1 = timeToX(visibleStart);
      const x2 = timeToX(visibleEnd);
      const zoneW = x2 - x1;
      const ratio = gapSec / idealGap;
      const solidColor = ratio < 0.5 ? '#E52E2E' : ratio < 0.8 ? '#FBBF24' : ratio <= 1.3 ? '#10B981' : '#60A5FA';

      ctx.fillStyle = solidColor;
      ctx.globalAlpha = 0.82;
      ctx.fillRect(x1 + 1, h - 3, Math.max(zoneW - 2, 0), 3);
      ctx.globalAlpha = 1.0;

      if (zoneW > 42) {
        const gapMin = Math.floor(gapSec / 60);
        const gapRemSec = Math.floor(gapSec % 60);
        const gapLabel = gapMin > 0
          ? `${gapMin}:${String(gapRemSec).padStart(2, '0')}`
          : `${Math.floor(gapSec)}с`;

        ctx.font = '800 11px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
        const tw = ctx.measureText(gapLabel).width;
        const labelY = Math.round(h * 0.58);
        const labelX = Math.max(x1 + 4, Math.min(x1 + zoneW / 2 - tw / 2, x2 - tw - 4));

        ctx.save();
        ctx.shadowColor = 'rgba(0, 0, 0, 0.65)';
        ctx.shadowBlur = 5;
        ctx.fillStyle = 'rgba(255,255,255,0.58)';
        ctx.fillText(gapLabel, labelX, labelY);
        ctx.restore();
      }
    }
  }

  // ── Жовті вертикалі: паузи, куди ще можна поставити вручну ──
  if (state.waveformManualHints !== false) {
    state.silences.forEach(s => {
      const alreadySelected = state.selected.some(sel => Math.abs(sel.seconds - s.seconds) < 1);
      if (alreadySelected) return;
      if (!isTimeVisible(s.seconds)) return;

      const sx = timeToX(s.seconds);
      const quality = Math.max(0, Math.min(1, Number(s.quality_score) || 0.45));
      const lineAlpha = 0.22 + quality * 0.36;
      const glowAlpha = 0.1 + quality * 0.28;
      const lineWidth = 0.75 + quality * 0.45;
      const dashOn = quality >= 0.78 ? 5 : 3;
      const dashOff = quality >= 0.55 ? 4 : 5;

      ctx.save();
      ctx.strokeStyle = `rgba(251, 191, 36, ${lineAlpha.toFixed(2)})`;
      ctx.lineWidth = lineWidth;
      ctx.shadowColor = `rgba(251, 191, 36, ${glowAlpha.toFixed(2)})`;
      ctx.shadowBlur = 2 + quality * 3;
      ctx.setLineDash([dashOn, dashOff]);
      ctx.beginPath();
      ctx.moveTo(sx, 6);
      ctx.lineTo(sx, h - 11);
      ctx.stroke();
      ctx.setLineDash([]);

      ctx.fillStyle = `rgba(251, 191, 36, ${Math.min(0.68, lineAlpha + 0.12).toFixed(2)})`;
      ctx.beginPath();
      ctx.arc(sx, 7, 1.3 + quality * 0.6, 0, Math.PI * 2);
      ctx.fill();

      ctx.globalAlpha = Math.min(0.55, 0.2 + quality * 0.28);
      ctx.fillRect(sx - 3, h - 9, 6, 2);
      ctx.restore();
    });
  }

  // ── Маркери ──
  const markerBadgeLevels = [];
  const visibleMarkers = state.selected
    .map((s, i) => ({ s, i }))
    .filter(({ s }) => isTimeVisible(s.seconds));
  const denseMarkers = visibleMarkers.length > 14;
  visibleMarkers.forEach(({ s, i }) => {

    const x = timeToX(s.seconds);
    const isManual = s.manual;
    const color = isManual ? '#FBBF24' : '#E52E2E';
    const strokeColor = isManual ? 'rgba(245, 158, 11, 0.9)' : 'rgba(239, 68, 68, 0.78)';

    ctx.save();
    ctx.strokeStyle = strokeColor;
    ctx.lineWidth = isManual ? 1.15 : 0.95;
    ctx.shadowColor = color;
    ctx.shadowBlur = denseMarkers ? 2 : (isManual ? 4 : 3);
    ctx.beginPath();
    ctx.moveTo(x, 1);
    ctx.lineTo(x, h - 5);
    ctx.stroke();

    const label = isManual ? `✋${i + 1}` : `${i + 1}`;
    ctx.shadowBlur = 0;
    ctx.font = `${denseMarkers ? '800 9px' : '850 10px'} -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif`;
    const tw = ctx.measureText(label).width;
    const badgeW = Math.max(denseMarkers ? 12 : 14, tw + (denseMarkers ? 5 : 7));
    const badgeH = denseMarkers ? 12 : 14;
    let level = 0;
    while (markerBadgeLevels[level] !== undefined && Math.abs(markerBadgeLevels[level] - x) < badgeW + 3) {
      level++;
    }
    markerBadgeLevels[level] = x;

    const badgeX = Math.max(2, Math.min(x - badgeW / 2, w - badgeW - 2));
    const badgeY = 3 + Math.min(level, denseMarkers ? 2 : 3) * (denseMarkers ? 10 : 12);
    const badgeFill = denseMarkers ? 'rgba(7, 8, 11, 0.48)' : 'rgba(7, 8, 11, 0.58)';
    const badgeBorder = isManual ? 'rgba(245, 158, 11, 0.62)' : 'rgba(239, 68, 68, 0.62)';

    ctx.fillStyle = badgeFill;
    ctx.beginPath();
    if (ctx.roundRect) ctx.roundRect(badgeX, badgeY, badgeW, badgeH, 4);
    else ctx.fillRect(badgeX, badgeY, badgeW, badgeH);
    ctx.fill();
    ctx.strokeStyle = badgeBorder;
    ctx.lineWidth = 0.9;
    if (ctx.roundRect) {
      ctx.beginPath();
      ctx.roundRect(badgeX, badgeY, badgeW, badgeH, 4);
      ctx.stroke();
    }

    ctx.fillStyle = isManual ? '#FBBF24' : '#FF3B3B';
    ctx.textBaseline = 'middle';
    ctx.fillText(label, badgeX + (denseMarkers ? 2.5 : 3.5), badgeY + badgeH / 2 + 0.5);
    ctx.textBaseline = 'alphabetic';
    ctx.restore();
  });

  // ── Часові мітки ──
  ctx.fillStyle = '#52525B';
  ctx.font = '500 8px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
  ctx.shadowBlur = 0;
  const timeMarks = 6;
  for (let i = 0; i <= timeMarks; i++) {
    const x = (i / timeMarks) * w;
    const timeSec = view.start + (i / timeMarks) * view.viewDuration;
    const m = Math.floor(timeSec / 60);
    const s = Math.floor(timeSec % 60);
    const timeStr = s > 0 ? `${m}:${String(s).padStart(2, '0')}` : `${m}m`;

    let textX = x + 2;
    if (i === timeMarks) textX = x - ctx.measureText(timeStr).width - 2;
    else if (i !== 0) textX = x - ctx.measureText(timeStr).width / 2;

    ctx.fillText(timeStr, textX, h - 7);
  }

  if (typeof updateWaveformZoomUI === 'function') updateWaveformZoomUI();
  if (needsRedraw) log('Вейвформа: повний рендер', 'info');
}
