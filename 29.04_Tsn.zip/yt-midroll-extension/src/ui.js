// ─── ШАБЛОНИ UI ──────────────────────────────────────────────────────────────
function row(label, ctrl, hint = '') {
  const tipHtml = hint
    ? `<span style="cursor:help;margin-left:3px;opacity:0.5;font-size:10px;flex-shrink:0;" title="${hint.replace(/"/g, '&quot;').replace(/\n/g, '&#10;')}">ℹ️</span>`
    : '';
  return `<div class="mr"><span class="ml">${label}${tipHtml}</span><span class="mc">${ctrl}</span></div>`;
}


function stepper(id, val, min, max, step) {
  return `<div class="stp" data-id="${id}" data-val="${val}" data-min="${min}" data-max="${max}" data-step="${step}">
    <button class="mcb stp-m">−</button>
    <input type="text" class="stp-v" value="${val}" spellcheck="false" readonly title="Натисніть щоб ввести значення вручну">
    <button class="mcb stp-p">+</button>
  </div>`;
}

function getVal(id) {
  const el = document.querySelector(`.stp[data-id="${id}"] .stp-v`);
  return el ? parseFloat(el.value) : null;
}

function _setStepperVal(id, val) {
  const el = document.querySelector(`.stp[data-id="${id}"] .stp-v`);
  if (el && val !== undefined && val !== null) el.value = val;
}

function _restoreSettingsToUI() {
  _setStepperVal('mra-min-silence', CONFIG.minSilenceSec);
  _setStepperVal('mra-threshold', CONFIG.silenceThresholdPct);
  _setStepperVal('mra-min-gap', CONFIG.minGapSec);
  _setStepperVal('mra-cutoff', CONFIG.shortVideoCutoff / 60); // Зберігається в секундах, відображається в хвилинах
  _setStepperVal('mra-short-gap', CONFIG.shortVideoGapSec);
  _setStepperVal('mra-long-gap', CONFIG.longVideoGapSec);

  const focusCb = document.getElementById('mra-focus-start');
  if (focusCb) focusCb.checked = CONFIG.focusStart;

  const autoOpenCb = document.getElementById('mra-auto-open');
  if (autoOpenCb) autoOpenCb.checked = CONFIG.autoOpenPanel;

  const autosaveCb = document.getElementById('mra-autosave');
  if (autosaveCb) autosaveCb.checked = CONFIG.autoSaveAfterInsert;

  const autoGapCb = document.getElementById('mra-auto-gap');
  if (autoGapCb) {
    autoGapCb.checked = CONFIG.autoGap;
    document.getElementById('mra-auto-sect').style.display = CONFIG.autoGap ? '' : 'none';
    document.getElementById('mra-manual-sect').style.display = CONFIG.autoGap ? 'none' : '';
  }
}

// ─── UI ПАНЕЛЬ ────────────────────────────────────────────────────────────────
function createPanel() {
  if (document.getElementById('mra-panel')) return;

  const panel = document.createElement('div');
  panel.id = 'mra-panel';
  panel.innerHTML = `
<style>
#mra-panel{position:fixed;top:72px;right:16px;z-index:99999;background:rgba(18,18,20,0.85);backdrop-filter:blur(16px);-webkit-backdrop-filter:blur(16px);color:#e0e0e0;border-radius:12px;border:1px solid rgba(255,255,255,0.08);box-shadow:0 10px 40px rgba(0,0,0,0.8), 0 0 20px rgba(229,46,46,0.15);font-family:'Roboto',sans-serif;font-size:11px;width:310px;overflow:hidden;user-select:none;display:flex;flex-direction:column;max-height:calc(100vh - 100px);transition:box-shadow 0.3s ease, opacity 0.3s ease;resize:both;min-width:280px;min-height:200px;}
#mra-header{background:rgba(0,0,0,0.3);padding:8px 12px;display:flex;align-items:center;justify-content:space-between;cursor:move;border-bottom:1px solid rgba(229,46,46,0.4);flex-shrink:0;}
#mra-title{font-weight:900;font-size:13px;color:#ffffff;text-transform:uppercase;letter-spacing:0.5px;display:flex;align-items:center;text-shadow:0 0 8px rgba(255,255,255,0.2);}
#mra-minimize, #mra-close, #mra-reload{background:none;border:none;color:#888;cursor:pointer;font-size:16px;padding:0;line-height:1;margin-left:6px;transition:all 0.2s;}
#mra-minimize:hover{color:#fff;text-shadow:0 0 8px rgba(255,255,255,0.5);}
#mra-close:hover{color:#ff4d4d;text-shadow:0 0 8px rgba(255,77,77,0.5);}
#mra-reload:hover{color:#06d6a0;text-shadow:0 0 8px rgba(6,214,160,0.5);}
#mra-body{padding:8px 10px;overflow-y:auto;overflow-x:hidden;}
.ms{margin-bottom:8px;background:rgba(255,255,255,0.02);padding:8px;border-radius:8px;border:1px solid rgba(255,255,255,0.05);}
.mst{font-size:10px;font-weight:900;color:#E52E2E;letter-spacing:.5px;text-transform:uppercase;margin-bottom:6px;padding-bottom:2px;border-bottom:1px solid rgba(255,255,255,0.05);text-shadow:0 0 8px rgba(229,46,46,0.4);}
.mr{display:flex;align-items:center;gap:4px;margin-bottom:4px;flex-wrap:wrap}
.ml{color:#bbb;font-size:10px;flex:1;min-width:110px}
.mc{display:flex;align-items:center;gap:4px}
.mh{color:#666;font-size:10px;width:100%;padding-left:4px}
.mcnt,.stp{display:flex;align-items:center;gap:4px}
.mcb{width:20px;height:20px;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);color:#e0e0e0;border-radius:4px;cursor:pointer;font-size:12px;line-height:1;padding:0;display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:all 0.2s;}
.mcb:hover{background:#E52E2E;color:#fff;border-color:#E52E2E;box-shadow:0 0 8px rgba(229,46,46,0.5);}
#mra-count,.stp-v{width:40px;text-align:center;color:#fff;font-size:12px;font-weight:900;background:rgba(0,0,0,0.5);border:1px solid rgba(255,255,255,0.1);border-radius:4px;padding:2px 0;cursor:pointer;transition:all 0.2s;user-select:text;-webkit-user-select:text;}
.stp-v:focus{outline:none;border-color:#E52E2E;background:rgba(229,46,46,0.1);box-shadow:0 0 8px rgba(229,46,46,0.4)}
#mra-count{color:#E52E2E;font-size:14px;width:auto;min-width:34px;padding:2px 4px;text-shadow:0 0 8px rgba(229,46,46,0.4);}
.mtw{display:flex;align-items:center;gap:6px;margin-bottom:4px}
.mt{position:relative;width:28px;height:16px;display:inline-block}
.mt input{opacity:0;width:0;height:0}
.msl{position:absolute;inset:0;background:rgba(255,255,255,0.1);border-radius:18px;cursor:pointer;transition:.3s}
.msl:before{content:'';position:absolute;height:12px;width:12px;left:2px;bottom:2px;background:#aaa;border-radius:50%;transition:.3s;box-shadow:0 2px 4px rgba(0,0,0,0.5);}
input:checked+.msl{background:#E52E2E;box-shadow:0 0 10px rgba(229,46,46,0.4);}
input:checked+.msl:before{transform:translateX(12px);background:#fff}
.mtl{color:#bbb;font-size:10px}
#mra-analyze,#mra-insert,#mra-clear{width:100%;padding:8px;border:none;border-radius:6px;cursor:pointer;font-size:11px;font-weight:900;text-transform:uppercase;letter-spacing:0.5px;transition:all .3s;margin-bottom:6px;position:relative;overflow:hidden;}
#mra-analyze{background:#E52E2E;color:#ffffff;box-shadow:0 4px 15px rgba(229,46,46,0.3);}
#mra-analyze:hover{background:#ff3333;transform:translateY(-1px);box-shadow:0 6px 20px rgba(229,46,46,0.5);}
#mra-insert{background:rgba(229,46,46,0.1);color:#E52E2E;border:1px solid rgba(229,46,46,0.3);}
#mra-insert:hover:not(:disabled){background:#E52E2E;color:#fff;box-shadow:0 4px 15px rgba(229,46,46,0.4);}
#mra-insert:disabled{opacity:.4;cursor:not-allowed;border-color:rgba(255,255,255,0.1);color:#777;background:rgba(255,255,255,0.02);}
#mra-clear{background:rgba(255,255,255,0.05);color:#bbb;border:1px solid rgba(255,255,255,0.1);margin-bottom:8px}
#mra-clear:hover{background:rgba(255,255,255,0.1);color:#fff;border-color:rgba(255,255,255,0.2);}
#mra-list{margin:4px 0;max-height:100px;overflow-y:auto;padding-right:4px;}
#mra-list::-webkit-scrollbar{width:4px}
#mra-list::-webkit-scrollbar-track{background:rgba(0,0,0,0.2);border-radius:2px;}
#mra-list::-webkit-scrollbar-thumb{background:rgba(255,255,255,0.2);border-radius:2px}
#mra-list::-webkit-scrollbar-thumb:hover{background:rgba(255,255,255,0.3);}
#mra-divider{border:none;border-top:1px solid rgba(255,255,255,0.1);margin:6px 0}
#mra-progress-wrap{height:6px;background:rgba(0,0,0,0.5);border-radius:3px;margin:8px 0;overflow:hidden;border:1px solid rgba(255,255,255,0.05);}
#mra-progress-bar{height:100%;background:linear-gradient(90deg, #E52E2E, #ff6b6b);width:0%;transition:width .3s ease-out;border-radius:3px;box-shadow:0 0 10px rgba(229,46,46,0.5);}
#mra-progress-label{color:#888;font-size:10px;text-align:right;margin-bottom:4px}
#mra-status{font-size:11px;color:#ccc;min-height:16px;word-break:break-word;line-height:1.4;text-align:center;padding:6px;background:rgba(0,0,0,0.2);border-radius:6px;border:1px solid rgba(255,255,255,0.05);}
.mra-wave-card{position:relative;overflow:hidden;padding:10px;background:linear-gradient(180deg,rgba(22,22,25,.96),rgba(9,10,12,.98));border-color:rgba(255,255,255,.1);border-radius:10px;box-shadow:inset 0 1px 0 rgba(255,255,255,.06),0 18px 45px rgba(0,0,0,.34);}
.mra-wave-card:before{content:'';position:absolute;left:10px;right:10px;top:0;height:1px;background:linear-gradient(90deg,rgba(229,46,46,.75),rgba(34,211,238,.65),rgba(251,191,36,.55));opacity:.9;}
.mra-wave-head{display:flex;align-items:flex-start;justify-content:space-between;gap:10px;margin-bottom:9px;position:relative;}
.mra-wave-title{min-width:0;}
.mra-wave-kicker{display:flex;align-items:center;gap:7px;color:#f9fafb;font-size:11px;font-weight:800;letter-spacing:.2px;text-transform:none;}
.mra-wave-dot{width:7px;height:7px;border-radius:50%;background:#2dd4bf;box-shadow:0 0 14px rgba(45,212,191,.72);}
.mra-wave-sub{margin-top:2px;color:#8b95a5;font-size:9.5px;line-height:1.25;}
.mra-wave-live{flex-shrink:0;color:#f8fafc;font-size:8.5px;font-weight:800;letter-spacing:.5px;text-transform:uppercase;padding:4px 7px;border:1px solid rgba(45,212,191,.22);border-radius:999px;background:rgba(255,255,255,.045);box-shadow:inset 0 1px 0 rgba(255,255,255,.06);}
#mra-waveform{display:block;width:100%;height:104px;box-sizing:border-box;border:1px solid rgba(255,255,255,.1);border-radius:9px;cursor:crosshair;background:#101114;box-shadow:inset 0 1px 0 rgba(255,255,255,.04),0 10px 24px rgba(0,0,0,.22);}
.mra-wave-toolbar{display:grid;grid-template-columns:88px minmax(96px,1fr);align-items:center;gap:8px;margin-top:9px;}
.mra-wave-zoom-group{display:grid;grid-template-columns:24px 1fr 24px;align-items:center;gap:1px;padding:3px;background:rgba(255,255,255,.055);border:1px solid rgba(255,255,255,.08);border-radius:999px;box-shadow:inset 0 1px 0 rgba(255,255,255,.04);}
.mra-wave-btn{height:24px;min-width:24px;padding:0;border:0;border-radius:999px;background:transparent;color:#aeb8c6;cursor:pointer;font-size:12px;font-weight:900;line-height:1;display:flex;align-items:center;justify-content:center;transition:background .16s ease,color .16s ease,transform .16s ease;}
.mra-wave-btn:hover{background:rgba(255,255,255,.09);color:#fff;transform:translateY(-1px);}
#mra-wave-zoom-reset{min-width:34px;color:#fff;font-size:10px;font-weight:900;background:transparent;border-left:1px solid rgba(255,255,255,.07);border-right:1px solid rgba(255,255,255,.07);border-radius:0;}
#mra-wave-pan{-webkit-appearance:none;appearance:none;width:100%;min-width:0;height:24px;margin:0;background:transparent;accent-color:#2dd4bf;}
#mra-wave-pan::-webkit-slider-runnable-track{height:6px;border-radius:999px;background:linear-gradient(90deg,rgba(45,212,191,.85),rgba(245,158,11,.75));box-shadow:inset 0 0 0 1px rgba(255,255,255,.1),0 8px 20px rgba(0,0,0,.25);}
#mra-wave-pan::-webkit-slider-thumb{-webkit-appearance:none;width:18px;height:18px;margin-top:-6px;border-radius:50%;background:#f9fafb;border:1px solid rgba(255,255,255,.9);box-shadow:0 6px 16px rgba(0,0,0,.48),0 0 0 4px rgba(45,212,191,.18);}
#mra-wave-pan::-moz-range-track{height:6px;border-radius:999px;background:linear-gradient(90deg,rgba(45,212,191,.85),rgba(245,158,11,.75));}
#mra-wave-pan::-moz-range-thumb{width:18px;height:18px;border-radius:50%;background:#f9fafb;border:1px solid rgba(255,255,255,.9);}
.mra-wave-hints-toggle{display:grid;grid-template-columns:auto minmax(0,1fr) auto;align-items:center;gap:8px;margin-top:9px;padding:7px 8px;border-radius:9px;background:rgba(255,255,255,.045);border:1px solid rgba(255,255,255,.08);color:#b8c0cc;font-size:9.5px;line-height:1.2;cursor:pointer;box-shadow:inset 0 1px 0 rgba(255,255,255,.035);}
.mra-wave-hints-toggle input{position:absolute;opacity:0;pointer-events:none;}
.mra-wave-switch{position:relative;width:31px;height:18px;flex-shrink:0;border-radius:999px;background:rgba(148,163,184,.18);box-shadow:inset 0 0 0 1px rgba(255,255,255,.08);transition:background .18s ease,box-shadow .18s ease;}
.mra-wave-switch:before{content:'';position:absolute;width:14px;height:14px;left:2px;top:2px;border-radius:50%;background:#f8fafc;box-shadow:0 3px 10px rgba(0,0,0,.42);transition:transform .18s ease;}
.mra-wave-hints-toggle input:checked+.mra-wave-switch{background:rgba(245,158,11,.9);box-shadow:0 0 16px rgba(245,158,11,.18);}
.mra-wave-hints-toggle input:checked+.mra-wave-switch:before{transform:translateX(13px);background:#111827;}
.mra-wave-hints-toggle.is-off{color:#717b8b;}
.mra-wave-hints-toggle.is-off .mra-wave-switch{background:rgba(148,163,184,.16);box-shadow:inset 0 0 0 1px rgba(148,163,184,.12);}
.mra-wave-hints-copy{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.mra-wave-state{padding:3px 6px;border-radius:999px;background:rgba(245,158,11,.14);color:#fbbf24;font-weight:900;text-transform:uppercase;letter-spacing:.35px;}
.mra-wave-hints-toggle.is-off .mra-wave-state{background:rgba(148,163,184,.1);color:#7b8493;}
.mra-wave-legend{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-top:8px;color:#778294;font-size:8.8px;}
.mra-wave-chip{display:inline-flex;align-items:center;gap:4px;white-space:nowrap;}
.mra-wave-swatch{width:13px;height:2px;border-radius:999px;display:inline-block;background:#ef4444;box-shadow:0 0 8px rgba(239,68,68,.42);}
.mra-wave-swatch.manual{background:#f59e0b;box-shadow:0 0 8px rgba(245,158,11,.35);}
.mra-wave-swatch.sound{width:5px;height:11px;background:#d1d5db;box-shadow:none;}
.mra-wave-swatch.hint{width:2px;height:11px;background:#f59e0b;box-shadow:0 0 8px rgba(245,158,11,.28);}
@keyframes mra-pulse-red{0%,100%{box-shadow:0 0 5px rgba(229,46,46,0.2);border-color:rgba(229,46,46,0.3)}50%{box-shadow:0 0 15px rgba(229,46,46,0.8);border-color:rgba(229,46,46,0.8)}}
@keyframes mra-pulse-yellow{0%,100%{box-shadow:0 0 5px rgba(251,191,36,0.2);border-color:rgba(251,191,36,0.3)}50%{box-shadow:0 0 15px rgba(251,191,36,0.8);border-color:rgba(251,191,36,0.8)}}
.mra-pulse-red{animation:mra-pulse-red 2s ease-in-out infinite}
.mra-pulse-yellow{animation:mra-pulse-yellow 2.5s ease-in-out infinite}
</style>

<div id="mra-header">
  <div id="mra-title"><span style="background:#E52E2E;color:#fff;padding:2px 6px;border-radius:4px;margin-right:8px;box-shadow:0 0 10px rgba(229,46,46,0.5);">ТСН</span> АВТОРЕКЛАМА</div>
  <div style="display:flex;align-items:center;gap:6px">
    <button id="mra-reload" title="Перезапустити розширення (Очистити дані)">↻</button>
    <button id="mra-minimize" title="Згорнути">−</button>
    <button id="mra-close" title="Закрити панель">✕</button>
  </div>
</div>

<div id="mra-body">

  <div class="ms">
    <div class="mst">📊 Основне</div>
    <div style="color:#ffffff;font-size:11px;padding:4px 0;font-weight:600;opacity:0.9;text-align:center;">
      🫠 Авто-режим
      <div style="margin-top:4px;font-weight:400;opacity:0.8;">ставимо рекламу скільки можна через 1.5-2 хв</div>
    </div>
    <div style="margin-top:8px;">
      <div class="mtw">
        <label class="mt"><input type="checkbox" id="mra-focus-start" checked><span class="msl"></span></label>
        <span class="mtl" style="color:#ffffff;opacity:0.85;font-weight:500;">🎯 Більше реклами на початку (x2 буст)</span>
      </div>
      <div class="mtw" style="margin-top:6px;">
        <label class="mt"><input type="checkbox" id="mra-auto-open" checked><span class="msl"></span></label>
        <span class="mtl">🔄 Автоматично відкривати панель</span>
      </div>
      <div class="mtw" style="margin-top:6px;">
        <label class="mt"><input type="checkbox" id="mra-autosave" checked><span class="msl"></span></label>
        <span class="mtl">💾 Автозбереження (Продовжити + Зберегти)</span>
      </div>
    </div>
  </div>

  <div class="ms">
    <div class="mst">🔇 Де ставити рекламу</div>
    ${row('Мін. пауза для реклами (с):', stepper('mra-min-silence', 1.5, 0.1, 30, 0.1), 'БОТ СТАВИТЬ РЕКЛАМУ ЛИШЕ ТАМ, ДЕ Є ПАУЗА ДОВША ЗА N СЕКУНД!\nМісця з коротшою тишею — ПРОПУСКАЮТЬСЯ. Рекомендовано: 1.5-3 сек')}
    ${row('Чутливість до тиші (%):', stepper('mra-threshold', 15, 1, 50, 1), '↓ менше % = строгіше, тільки дуже тихі місця\n↑ більше % = мʼякше, бот бачить більше пауз')}
  </div>

  <div class="ms">
    <div class="mst">↔️ Відстань між рекламами</div>
    <div class="mtw">
      <label class="mt"><input type="checkbox" id="mra-auto-gap" checked><span class="msl"></span></label>
      <span class="mtl" title="Бот сам підбирає частоту реклами залежно від довжини відео">🤖 Авто (бот вирішує сам)</span>
    </div>
    <div id="mra-auto-sect">
      ${row('Короткі відео — до (хв):', stepper('mra-cutoff', 10, 1, 120, 1), 'Відео коротше цього = "коротке". Наприклад: 10 хв → відео до 10 хв вважаються короткими')}
      ${row('Реклама кожні (с) — короткі:', stepper('mra-short-gap', 60, 1, 600, 1), 'Для коротких відео: ставити рекламу кожні N секунд')}
      ${row('Реклама кожні (с) — довгі:', stepper('mra-long-gap', 120, 1, 3600, 1), 'Для довгих відео: ставити рекламу кожні N секунд')}
    </div>
    <div id="mra-manual-sect" style="display:none">
      ${row('Мінімум між рекламами (с):', stepper('mra-min-gap', 120, 1, 7200, 1), 'Ручний режим: не ставити дві реклами ближче, ніж вказана кількість секунд')}
    </div>
  </div>

  <button id="mra-analyze">🔴 Аналізувати паузи</button>

  <div class="ms mra-wave-card" id="mra-waveform-section" style="display:none;">
    <div class="mra-wave-head">
      <div class="mra-wave-title">
        <div class="mra-wave-kicker"><span class="mra-wave-dot"></span>Вейвформа</div>
        <div class="mra-wave-sub">Реальні паузи та місця для ручної мітки</div>
      </div>
      <div class="mra-wave-live">аналіз</div>
    </div>
    <canvas id="mra-waveform" width="282" height="104" title="Клік по жовтій вертикалі = додати/видалити мітку"></canvas>
    <div class="mra-wave-toolbar" id="mra-wave-zoom">
      <div class="mra-wave-zoom-group">
        <button class="mra-wave-btn" id="mra-wave-zoom-out" title="Віддалити">−</button>
        <button class="mra-wave-btn" id="mra-wave-zoom-reset" title="Скинути масштаб">100%</button>
        <button class="mra-wave-btn" id="mra-wave-zoom-in" title="Наблизити">+</button>
      </div>
      <input id="mra-wave-pan" type="range" min="0" max="100" step="0.01" value="0" title="Позиція у збільшеній вейвформі">
    </div>
    <label class="mra-wave-hints-toggle" id="mra-wave-hints-wrap" title="Показувати жовті вертикалі, де ще можна вручну поставити рекламу">
      <input id="mra-wave-hints" type="checkbox" checked>
      <span class="mra-wave-switch"></span>
      <span class="mra-wave-hints-copy">Підказувати, куди можна поставити</span>
      <span class="mra-wave-state" id="mra-wave-hints-label">так</span>
    </label>
    <div class="mra-wave-legend">
      <span class="mra-wave-chip"><span class="mra-wave-swatch"></span>авто</span>
      <span class="mra-wave-chip"><span class="mra-wave-swatch manual"></span>вручну</span>
      <span class="mra-wave-chip"><span class="mra-wave-swatch sound"></span>звук</span>
      <span class="mra-wave-chip"><span class="mra-wave-swatch hint"></span>можна вручну</span>
    </div>
  </div>

  <div id="mra-stats" style="display:none; padding:8px; margin-bottom:8px; background:#1a1a1a; border-radius:6px; border:1px solid #333; text-align:center; font-size:12px; font-weight:600;"></div>
  <div id="mra-list"></div>
  <hr id="mra-divider">
  <button id="mra-insert" disabled>⚡ Вставити маркери</button>
  <button id="mra-clear">🗑️ Очистити всі мітки на відео</button>
  <div id="mra-progress-label"></div>
  <div id="mra-progress-wrap"><div id="mra-progress-bar"></div></div>
  <div id="mra-status">Готовий до роботи</div>
</div>
  `;

  document.body.appendChild(panel);

  // ── Відновлюємо розміри панелі ──
  safeChromeStorageGet(['mraPanelWidth', 'mraPanelHeight'], (data) => {
    if (data.mraPanelWidth) panel.style.width = data.mraPanelWidth;
    if (data.mraPanelHeight) panel.style.height = data.mraPanelHeight;
  });

  // ── Зберігаємо розміри панелі при розтягуванні ──
  let resizeTimer;
  new ResizeObserver(() => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => {
      if (panel.style.width || panel.style.height) {
        safeChromeStorageSet({
          mraPanelWidth: panel.style.width,
          mraPanelHeight: panel.style.height
        });
      }
    }, 500);
  }).observe(panel);

  // ── Відновлюємо збережені налаштування в UI ──
  _restoreSettingsToUI();

  // ── ГЛОБАЛЬНЕ ЗАХОПЛЕННЯ КЛАВІАТУРИ (з трекінгом для cleanup) ──
  const keyBlocker = (e) => {
    if (e.target && e.target.classList && e.target.classList.contains('stp-v')) {
      e.stopImmediatePropagation();
      e.stopPropagation();
    }
  };
  ['keydown', 'keyup', 'keypress'].forEach(evtType => {
    addTrackedEventListener(window, evtType, keyBlocker, { capture: true });
  });

  // ── Авто-перерахунок при зміні налаштувань ──
  let analyzeTimer = null;
  function triggerAutoAnalyze() {
    clearTimeout(analyzeTimer);
    analyzeTimer = setTimeout(() => {
      readSettings();
      saveSettings();
      if (state.cachedAudioBuffer) {
        analyzeWaveform().catch(e => console.error(e));
      }
    }, 250);
  }

  // ── Прив'язуємо stepper-кнопки (−/+) до всіх контролів ──
  panel.querySelectorAll('.stp').forEach(stp => {
    const valEl = stp.querySelector('.stp-v');
    const minVal = parseFloat(stp.dataset.min);
    const maxVal = parseFloat(stp.dataset.max);
    const step = parseFloat(stp.dataset.step);

    const updateVal = (newValStr) => {
      let next = parseFloat(newValStr);
      if (isNaN(next)) next = parseFloat(stp.dataset.val);
      if (next < minVal) next = minVal;
      if (next > maxVal) next = maxVal;
      valEl.value = Math.round(next * 1000) / 1000;
      triggerAutoAnalyze();
    };

    // ── Швидке прокручування при утриманні кнопки ──
    let holdTimer = null;
    let intervalTimer = null;

    const stopHold = () => {
      clearTimeout(holdTimer);
      clearInterval(intervalTimer);
      holdTimer = null;
      intervalTimer = null;
    };

    const startHold = (isPlus) => {
      stopHold(); // Очищаємо попередні таймери перед зачаттям нового

      const dir = isPlus ? 1 : -1;
      let cur = parseFloat(valEl.value) || parseFloat(stp.dataset.val);
      updateVal(cur + (step * dir));

      holdTimer = setTimeout(() => {
        intervalTimer = setInterval(() => {
          let current = parseFloat(valEl.value) || parseFloat(stp.dataset.val);
          updateVal(current + (step * dir * 5));
        }, 100);
      }, 400);
    };

    const btnM = stp.querySelector('.stp-m');
    const btnP = stp.querySelector('.stp-p');

    const attachPointerEvents = (btn, isPlus) => {
      const onDown = (e) => {
        if (e.button !== 0) return;
        e.preventDefault();
        btn.setPointerCapture(e.pointerId);
        startHold(isPlus);
      };
      const onUp = (e) => {
        btn.releasePointerCapture(e.pointerId);
        stopHold();
      };
      btn.addEventListener('pointerdown', onDown);
      btn.addEventListener('pointerup', onUp);
      btn.addEventListener('pointercancel', stopHold);
      btn.addEventListener('mouseleave', stopHold);
      activeEventListeners.push(
        { element: btn, event: 'pointerdown', handler: onDown, options: false },
        { element: btn, event: 'pointerup', handler: onUp, options: false },
        { element: btn, event: 'pointercancel', handler: stopHold, options: false },
        { element: btn, event: 'mouseleave', handler: stopHold, options: false }
      );
    };

    attachPointerEvents(btnM, false);
    attachPointerEvents(btnP, true);

    // Глобальний fallback
    addTrackedEventListener(window, 'mouseup', stopHold);
    addTrackedEventListener(window, 'touchend', stopHold);

    // Введення через Prompt
    valEl.style.cursor = 'pointer';
    const onValClick = () => {
      const currentVal = valEl.value;
      const newValStr = prompt(`Введіть нове значення (мінімум: ${minVal}, максимум: ${maxVal}):`, currentVal);
      if (newValStr !== null && newValStr.trim() !== '') {
        updateVal(newValStr.replace(',', '.'));
      }
    };
    addTrackedEventListener(valEl, 'click', onValClick);

    // ── Скрол коліщатком ──
    const onWheel = (e) => {
      e.preventDefault();
      e.stopPropagation();
      const cur = parseFloat(valEl.value) || parseFloat(stp.dataset.val);
      if (e.deltaY < 0) updateVal(cur + step);
      else updateVal(cur - step);
    };
    addTrackedEventListener(stp, 'wheel', onWheel, { passive: false });
  });

  // ── Тогл авто-gap ──
  const autoGapCb = document.getElementById('mra-auto-gap');
  autoGapCb.addEventListener('change', () => {
    document.getElementById('mra-auto-sect').style.display = autoGapCb.checked ? '' : 'none';
    document.getElementById('mra-manual-sect').style.display = autoGapCb.checked ? 'none' : '';
    triggerAutoAnalyze();
  });

  const focusStartCb = document.getElementById('mra-focus-start');
  if (focusStartCb) focusStartCb.addEventListener('change', triggerAutoAnalyze);

  const autoOpenCbEvt = document.getElementById('mra-auto-open');
  if (autoOpenCbEvt) {
    autoOpenCbEvt.addEventListener('change', () => {
      CONFIG.autoOpenPanel = autoOpenCbEvt.checked;
      saveSettings();
    });
  }

  const autosaveCbEvt = document.getElementById('mra-autosave');
  if (autosaveCbEvt) {
    autosaveCbEvt.addEventListener('change', () => {
      CONFIG.autoSaveAfterInsert = autosaveCbEvt.checked;
      saveSettings();
    });
  }

  // ── Аналізувати ──
  document.getElementById('mra-analyze').addEventListener('click', async () => {
    updateStatus('⏳ Аналізуємо...', 'info');
    try { await analyzeWaveform(); updateWaveformZoomUI(); }
    catch (e) { updateStatus('❌ Помилка: ' + e.message, 'error'); log(e.message, 'error'); }
  });

  function resetWaveformRenderCache() {
    offscreenCanvas = null;
    lastRenderSignature = null;
  }

  let waveformRenderFrame = null;
  function scheduleWaveformRender() {
    if (waveformRenderFrame) cancelAnimationFrame(waveformRenderFrame);
    waveformRenderFrame = requestAnimationFrame(() => {
      waveformRenderFrame = null;
      renderWaveform();
    });
  }

  function updateWaveformHintsLabel() {
    const hints = document.getElementById('mra-wave-hints');
    const label = document.getElementById('mra-wave-hints-label');
    const wrap = document.getElementById('mra-wave-hints-wrap');
    const enabled = state.waveformManualHints !== false;

    if (hints) hints.checked = enabled;
    if (label) {
      label.textContent = enabled ? 'так' : 'ні';
    }
    if (wrap) wrap.classList.toggle('is-off', !enabled);
  }

  function updateWaveformZoomUI() {
    const resetBtn = document.getElementById('mra-wave-zoom-reset');
    const pan = document.getElementById('mra-wave-pan');
    updateWaveformHintsLabel();
    if (!resetBtn || !pan) return;

    if (!state.waveformData || !state.waveformData.duration) {
      resetBtn.textContent = '100%';
      pan.value = '0';
      pan.disabled = true;
      return;
    }

    const view = getWaveformView(state.waveformData.duration);
    resetBtn.textContent = `${Math.round(view.zoom * 100)}%`;
    pan.disabled = view.zoom <= 1 || view.maxStart <= 0;
    pan.value = view.maxStart > 0 ? String((view.start / view.maxStart) * 100) : '0';
  }

  function setWaveformZoom(nextZoom, anchorRatio = 0.5) {
    if (!state.waveformData || !state.waveformData.duration) return;

    const duration = state.waveformData.duration;
    const currentView = getWaveformView(duration);
    const anchor = Math.max(0, Math.min(1, anchorRatio));
    const anchorSec = currentView.start + currentView.viewDuration * anchor;
    const zoom = Math.max(1, Math.min(16, nextZoom));
    const viewDuration = duration / zoom;

    state.waveformZoom = zoom;
    state.waveformOffsetSec = Math.max(0, Math.min(anchorSec - viewDuration * anchor, duration - viewDuration));
    resetWaveformRenderCache();
    updateWaveformZoomUI();
    scheduleWaveformRender();
  }

  function panWaveform(deltaSec) {
    if (!state.waveformData || !state.waveformData.duration) return;

    const view = getWaveformView(state.waveformData.duration);
    state.waveformOffsetSec = Math.max(0, Math.min(view.start + deltaSec, view.maxStart));
    resetWaveformRenderCache();
    updateWaveformZoomUI();
    scheduleWaveformRender();
  }

  const zoomOutBtn = document.getElementById('mra-wave-zoom-out');
  const zoomResetBtn = document.getElementById('mra-wave-zoom-reset');
  const zoomInBtn = document.getElementById('mra-wave-zoom-in');
  const wavePan = document.getElementById('mra-wave-pan');
  const waveHints = document.getElementById('mra-wave-hints');

  if (zoomOutBtn) zoomOutBtn.addEventListener('click', () => setWaveformZoom((state.waveformZoom || 1) / 1.2));
  if (zoomInBtn) zoomInBtn.addEventListener('click', () => setWaveformZoom((state.waveformZoom || 1) * 1.2));
  if (zoomResetBtn) zoomResetBtn.addEventListener('click', () => {
    state.waveformZoom = 1;
    state.waveformOffsetSec = 0;
    resetWaveformRenderCache();
    updateWaveformZoomUI();
    scheduleWaveformRender();
  });
  if (wavePan) wavePan.addEventListener('input', () => {
    if (!state.waveformData || !state.waveformData.duration) return;
    const view = getWaveformView(state.waveformData.duration);
    state.waveformOffsetSec = view.maxStart * ((parseFloat(wavePan.value) || 0) / 100);
    resetWaveformRenderCache();
    scheduleWaveformRender();
  });
  if (waveHints) {
    waveHints.checked = state.waveformManualHints !== false;
    waveHints.addEventListener('change', () => {
      state.waveformManualHints = waveHints.checked;
      updateWaveformHintsLabel();
      scheduleWaveformRender();
    });
  }
  globalThis.updateWaveformZoomUI = updateWaveformZoomUI;
  updateWaveformZoomUI();

  // ── Клік по вейвформі для додавання мітки вручну ──
  const waveformCanvas = document.getElementById('mra-waveform');
  if (waveformCanvas) {
    waveformCanvas.addEventListener('wheel', (e) => {
      if (!state.waveformData || !state.waveformData.duration) return;

      e.preventDefault();

      const rect = waveformCanvas.getBoundingClientRect();
      const anchorRatio = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
      const view = getWaveformView(state.waveformData.duration);

      if (e.shiftKey || Math.abs(e.deltaX) > Math.abs(e.deltaY)) {
        const delta = Math.abs(e.deltaX) > Math.abs(e.deltaY) ? e.deltaX : e.deltaY;
        panWaveform(delta * (view.viewDuration / Math.max(rect.width, 1)) * 1.2);
        return;
      }

      const zoomFactor = Math.max(0.86, Math.min(1.16, Math.exp(-e.deltaY * 0.0012)));
      setWaveformZoom((state.waveformZoom || 1) * zoomFactor, anchorRatio);
    }, { passive: false });

    waveformCanvas.addEventListener('click', (e) => {
      if (!state.waveformData) return;

      const rect = waveformCanvas.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const clickPercent = x / rect.width;
      const view = getWaveformView(state.waveformData.duration);
      const clickSec = view.start + clickPercent * view.viewDuration;

      // Перевірити, чи клік близько до існуючої мітки (для видалення)
      const existingIdx = state.selected.findIndex(s => Math.abs(s.seconds - clickSec) < 5);

      if (existingIdx !== -1) {
        state.selected.splice(existingIdx, 1);
        log(`Видалено мітку на ${toTimecode(clickSec)}`, 'warn');
        renderSelectedList();
        renderWaveform();
        return;
      }

      if (!state.silences || state.silences.length === 0) {
        log('❌ Немає знайдених пауз. Спочатку виконайте аналіз або змініть поріг тиші.', 'error');
        showHud('❌ Немає жовтих вертикалей пауз', 'error');
        return;
      }

      let closestSilence = null;
      let minDist = Infinity;
      let allowedSilence = null;

      state.silences.forEach(s => {
        const minVisualSec = view.viewDuration * (12 / rect.width);
        const halfDuration = Math.max((Number(s.ideal_duration_sec || s.duration_sec) || 0) / 2, minVisualSec / 2);
        const start = s.seconds - halfDuration;
        const end = s.seconds + halfDuration;
        const dist = Math.abs(s.seconds - clickSec);

        if (clickSec >= start && clickSec <= end) allowedSilence = s;
        if (dist < minDist) {
          minDist = dist;
          closestSilence = s;
        }
      });

      if (!allowedSilence) {
        const nearest = closestSilence ? ` Найближча пауза: ${toTimecode(closestSilence.seconds)}.` : '';
        log(`❌ Тут немає реальної паузи (${toTimecode(clickSec)}).${nearest}`, 'error');
        showHud(`❌ Клікніть по жовтій вертикалі паузи${closestSilence ? `\nнайближча: ${toTimecode(closestSilence.seconds)}` : ''}`, 'error');
        return;
      }

      closestSilence = allowedSilence;
      minDist = Math.abs(closestSilence.seconds - clickSec);
      const finalSec = closestSilence.seconds;

      // Перевіряємо чи мітка в межах відео
      if (finalSec < 0 || finalSec >= state.waveformData.duration) {
        log(`Таймкод за межами відео: ${toTimecode(finalSec)}`, 'error');
        updateStatus('❌ Таймкод за межами відео', 'error');
        return;
      }

      const snappedExistingIdx = state.selected.findIndex(s => Math.abs(s.seconds - finalSec) < 1);
      if (snappedExistingIdx !== -1) {
        state.selected.splice(snappedExistingIdx, 1);
        log(`Видалено мітку на ${toTimecode(finalSec)}`, 'warn');
        renderSelectedList();
        renderWaveform();
        return;
      }

      state.selected.push({
        timecode: toTimecode(finalSec),
        seconds: +finalSec.toFixed(2),
        duration_sec: closestSilence.duration_sec,
        ideal_duration_sec: closestSilence.ideal_duration_sec,
        amplitude: closestSilence.amplitude,
        quality_score: closestSilence.quality_score,
        quality_label: closestSilence.quality_label,
        silenceSource: 'detected',
        manual: true
      });
      state.selected.sort((a, b) => a.seconds - b.seconds);

      const distStr = minDist < 0.5 ? 'точно' : `±${minDist.toFixed(1)}с`;
      const msg = `🧲 Мітка: ${toTimecode(finalSec)}\n${distStr} від кліку · пауза ${closestSilence.duration_sec?.toFixed(1) || '?'}с`;
      log(msg.replace('\n', ' '), 'success');
      showHud(msg, 'success');
      updateStatus(`✅ Мітка на ${toTimecode(finalSec)}`, 'success');

      renderSelectedList();
      renderWaveform();
    });
  }


  // ── Вставити ──
  document.getElementById('mra-insert').addEventListener('click', insertTimecodes);

  // ── Очистити всі мітки (з YouTube) ──
  document.getElementById('mra-clear').addEventListener('click', async () => {
    updateStatus('🗑️ Очищення міток...', 'info');

    // 1. Знімаємо галочку "Автоматичні рекламні місця", інакше YouTube не дасть видалити свої мітки
    const autoAdsCheckbox = document.querySelector('div[role="checkbox"][aria-label="Автоматичні рекламні місця"]');
    if (autoAdsCheckbox && autoAdsCheckbox.getAttribute('aria-checked') === 'true') {
      log('⚙️ Вимикаємо "Автоматичні рекламні місця" від YouTube...', 'info');
      autoAdsCheckbox.click();
      await sleep(400); // Даємо час React застосувати зміни
    }

    let deleteBtns = getAdBreakDeleteButtons();

    if (deleteBtns.length === 0) {
      log('Не знайдено міток для видалення', 'warn');
      updateStatus('Не знайдено міток', 'warn');
      return;
    }

    const totalToDelete = deleteBtns.length;
    log(`Видаляємо ${totalToDelete} міток з відео...`, 'info');
    let deleted = 0;
    while (true) {
      deleteBtns = getAdBreakDeleteButtons();
      if (deleteBtns.length === 0) break;
      deleteBtns[deleteBtns.length - 1].click();
      deleted++;
      await sleep(150);
      if (deleted > totalToDelete + 10) break; // запобігаємо нескінченному циклу
    }

    updateStatus('🗑️ Всі реклами успішно видалено!', 'success');
  });

  // ── Мінімізувати та Закрити ──
  document.getElementById('mra-minimize').addEventListener('click', () => {
    const body = document.getElementById('mra-body');
    const btn = document.getElementById('mra-minimize');
    const hidden = body.style.display === 'none';
    body.style.display = hidden ? '' : 'none';
    btn.textContent = hidden ? '−' : '+';
  });

  document.getElementById('mra-close').addEventListener('click', () => {
    isPanelClosedByUser = true;
    panel.remove();
    createReopenButton();
  });

  // ── Перезавантаження ──
  document.getElementById('mra-reload').addEventListener('click', () => {
    log('♻️ Перезавантаження розширення та скидання налаштувань...', 'info');
    resetSettings();
    state.cachedAudioBuffer = null;
    state.cachedAudioUrl = null;
    state.waveformData = null;
    state.waveformZoom = 1;
    state.waveformOffsetSec = 0;
    state.waveformManualHints = true;
    state.silences = [];
    state.selected = [];
    offscreenCanvas = null;
    lastRenderSignature = null;
    isPanelClosedByUser = false;
    panel.remove();
    // НЕ викликаємо init(), бо він додасть ще один observer
    // Існуючий observer сам побачить, що панелі нема і перемалює її
  });

  // ── Drag (з трекінгом для cleanup) ──
  let isDragging = false, sx, sy, sl, st;
  document.getElementById('mra-header').addEventListener('mousedown', e => {
    if (e.target.tagName === 'BUTTON') return;
    isDragging = true; sx = e.clientX; sy = e.clientY;
    const r = panel.getBoundingClientRect(); sl = r.left; st = r.top;
    panel.style.right = 'auto';
  });

  const onMouseMove = e => {
    if (!isDragging) return;
    panel.style.left = (sl + e.clientX - sx) + 'px';
    panel.style.top = (st + e.clientY - sy) + 'px';
  };
  const onMouseUp = () => { isDragging = false; };

  addTrackedEventListener(document, 'mousemove', onMouseMove);
  addTrackedEventListener(document, 'mouseup', onMouseUp);
}

function createReopenButton() {
  if (document.getElementById('mra-reopen-btn')) return;
  const btn = document.createElement('button');
  btn.id = 'mra-reopen-btn';
  btn.innerHTML = '⚡ Відкрити ТСН АвтоРеклама';
  btn.style.cssText = `
    position: fixed;
    bottom: 24px;
    right: 24px;
    z-index: 10000;
    background: #e63946;
    color: white;
    border: none;
    border-radius: 8px;
    padding: 12px 24px;
    font-size: 15px;
    font-family: 'YouTube Noto', Roboto, Arial, sans-serif;
    font-weight: 500;
    cursor: pointer;
    box-shadow: 0 4px 12px rgba(0,0,0,0.4);
    transition: 0.2s;
  `;
  btn.onmouseover = () => { btn.style.transform = 'scale(1.05)'; btn.style.background = '#ff4d5a'; };
  btn.onmouseout = () => { btn.style.transform = 'scale(1)'; btn.style.background = '#e63946'; };

  btn.addEventListener('click', () => {
    isPanelClosedByUser = false;
    btn.remove();
    // MutationObserver відразу помітить isPanelClosedByUser = false і створить нову панель
  });

  document.body.appendChild(btn);
}
