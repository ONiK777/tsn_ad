// ─── ШАБЛОНИ UI ──────────────────────────────────────────────────────────────
function row(label, ctrl, hint = '') {
  const tipHtml = hint
    ? `<span style="cursor:help;margin-left:3px;opacity:0.5;font-size:10px;flex-shrink:0;" title="${hint.replace(/"/g, '&quot;').replace(/\n/g, '&#10;')}">ℹ️</span>`
    : '';
  return `<div class="mr"><span class="ml">${label}${tipHtml}</span><span class="mc">${ctrl}</span></div>`;
}


function stepper(id, val, min, max, step) {
  return `<div class="stp" data-id="${id}" data-val="${val}" data-min="${min}" data-max="${max}" data-step="${step}">
    <button class="mcb stp-m">−</button>
    <input type="text" class="stp-v" value="${val}" spellcheck="false" readonly title="Натисніть щоб ввести значення вручну">
    <button class="mcb stp-p">+</button>
  </div>`;
}

function getVal(id) {
  const el = document.querySelector(`.stp[data-id="${id}"] .stp-v`);
  return el ? parseFloat(el.value) : null;
}

function _setStepperVal(id, val) {
  const el = document.querySelector(`.stp[data-id="${id}"] .stp-v`);
  if (el && val !== undefined && val !== null) el.value = val;
}

function _restoreSettingsToUI() {
  _setStepperVal('mra-min-silence', CONFIG.minSilenceSec);
  _setStepperVal('mra-threshold', CONFIG.silenceThresholdPct);
  _setStepperVal('mra-min-gap', CONFIG.minGapSec);
  _setStepperVal('mra-cutoff', CONFIG.shortVideoCutoff / 60); // Зберігається в секундах, відображається в хвилинах
  _setStepperVal('mra-short-gap', CONFIG.shortVideoGapSec);
  _setStepperVal('mra-long-gap', CONFIG.longVideoGapSec);

  const focusCb = document.getElementById('mra-focus-start');
  if (focusCb) focusCb.checked = CONFIG.focusStart;

  const autoOpenCb = document.getElementById('mra-auto-open');
  if (autoOpenCb) autoOpenCb.checked = CONFIG.autoOpenPanel;

  const autosaveCb = document.getElementById('mra-autosave');
  if (autosaveCb) autosaveCb.checked = CONFIG.autoSaveAfterInsert;

  const autoGapCb = document.getElementById('mra-auto-gap');
  if (autoGapCb) {
    autoGapCb.checked = CONFIG.autoGap;
    document.getElementById('mra-auto-sect').style.display = CONFIG.autoGap ? '' : 'none';
    document.getElementById('mra-manual-sect').style.display = CONFIG.autoGap ? 'none' : '';
  }
}

// ─── UI ПАНЕЛЬ ────────────────────────────────────────────────────────────────
function createPanel() {
  if (document.getElementById('mra-panel')) return;

  const panel = document.createElement('div');
  panel.id = 'mra-panel';
  panel.innerHTML = `
<style>
#mra-panel{position:fixed;top:72px;right:16px;z-index:99999;background:rgba(18,18,20,0.85);backdrop-filter:blur(16px);-webkit-backdrop-filter:blur(16px);color:#e0e0e0;border-radius:12px;border:1px solid rgba(255,255,255,0.08);box-shadow:0 10px 40px rgba(0,0,0,0.8), 0 0 20px rgba(229,46,46,0.15);font-family:'Roboto',sans-serif;font-size:11px;width:310px;overflow:hidden;user-select:none;display:flex;flex-direction:column;max-height:calc(100vh - 100px);transition:box-shadow 0.3s ease, opacity 0.3s ease;resize:both;min-width:280px;min-height:200px;}
#mra-header{background:rgba(0,0,0,0.3);padding:8px 12px;display:flex;align-items:center;justify-content:space-between;cursor:move;border-bottom:1px solid rgba(229,46,46,0.4);flex-shrink:0;}
#mra-title{font-weight:900;font-size:13px;color:#ffffff;text-transform:uppercase;letter-spacing:0.5px;display:flex;align-items:center;text-shadow:0 0 8px rgba(255,255,255,0.2);}
#mra-minimize, #mra-close, #mra-reload{background:none;border:none;color:#888;cursor:pointer;font-size:16px;padding:0;line-height:1;margin-left:6px;transition:all 0.2s;}
#mra-minimize:hover{color:#fff;text-shadow:0 0 8px rgba(255,255,255,0.5);}
#mra-close:hover{color:#ff4d4d;text-shadow:0 0 8px rgba(255,77,77,0.5);}
#mra-reload:hover{color:#06d6a0;text-shadow:0 0 8px rgba(6,214,160,0.5);}
#mra-body{padding:8px 10px;overflow-y:auto;overflow-x:hidden;}
.ms{margin-bottom:8px;background:rgba(255,255,255,0.02);padding:8px;border-radius:8px;border:1px solid rgba(255,255,255,0.05);}
.mst{font-size:10px;font-weight:900;color:#E52E2E;letter-spacing:.5px;text-transform:uppercase;margin-bottom:6px;padding-bottom:2px;border-bottom:1px solid rgba(255,255,255,0.05);text-shadow:0 0 8px rgba(229,46,46,0.4);}
.mr{display:flex;align-items:center;gap:4px;margin-bottom:4px;flex-wrap:wrap}
.ml{color:#bbb;font-size:10px;flex:1;min-width:110px}
.mc{display:flex;align-items:center;gap:4px}
.mh{color:#666;font-size:10px;width:100%;padding-left:4px}
.mcnt,.stp{display:flex;align-items:center;gap:4px}
.mcb{width:20px;height:20px;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);color:#e0e0e0;border-radius:4px;cursor:pointer;font-size:12px;line-height:1;padding:0;display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:all 0.2s;}
.mcb:hover{background:#E52E2E;color:#fff;border-color:#E52E2E;box-shadow:0 0 8px rgba(229,46,46,0.5);}
#mra-count,.stp-v{width:40px;text-align:center;color:#fff;font-size:12px;font-weight:900;background:rgba(0,0,0,0.5);border:1px solid rgba(255,255,255,0.1);border-radius:4px;padding:2px 0;cursor:pointer;transition:all 0.2s;user-select:text;-webkit-user-select:text;}
.stp-v:focus{outline:none;border-color:#E52E2E;background:rgba(229,46,46,0.1);box-shadow:0 0 8px rgba(229,46,46,0.4)}
#mra-count{color:#E52E2E;font-size:14px;width:auto;min-width:34px;padding:2px 4px;text-shadow:0 0 8px rgba(229,46,46,0.4);}
.mtw{display:flex;align-items:center;gap:6px;margin-bottom:4px}
.mt{position:relative;width:28px;height:16px;display:inline-block}
.mt input{opacity:0;width:0;height:0}
.msl{position:absolute;inset:0;background:rgba(255,255,255,0.1);border-radius:18px;cursor:pointer;transition:.3s}
.msl:before{content:'';position:absolute;height:12px;width:12px;left:2px;bottom:2px;background:#aaa;border-radius:50%;transition:.3s;box-shadow:0 2px 4px rgba(0,0,0,0.5);}
input:checked+.msl{background:#E52E2E;box-shadow:0 0 10px rgba(229,46,46,0.4);}
input:checked+.msl:before{transform:translateX(12px);background:#fff}
.mtl{color:#bbb;font-size:10px}
#mra-analyze,#mra-insert,#mra-clear{width:100%;padding:8px;border:none;border-radius:6px;cursor:pointer;font-size:11px;font-weight:900;text-transform:uppercase;letter-spacing:0.5px;transition:all .3s;margin-bottom:6px;position:relative;overflow:hidden;}
#mra-analyze{background:#E52E2E;color:#ffffff;box-shadow:0 4px 15px rgba(229,46,46,0.3);}
#mra-analyze:hover{background:#ff3333;transform:translateY(-1px);box-shadow:0 6px 20px rgba(229,46,46,0.5);}
#mra-insert{background:rgba(229,46,46,0.1);color:#E52E2E;border:1px solid rgba(229,46,46,0.3);}
#mra-insert:hover:not(:disabled){background:#E52E2E;color:#fff;box-shadow:0 4px 15px rgba(229,46,46,0.4);}
#mra-insert:disabled{opacity:.4;cursor:not-allowed;border-color:rgba(255,255,255,0.1);color:#777;background:rgba(255,255,255,0.02);}
#mra-clear{background:rgba(255,255,255,0.05);color:#bbb;border:1px solid rgba(255,255,255,0.1);margin-bottom:8px}
#mra-clear:hover{background:rgba(255,255,255,0.1);color:#fff;border-color:rgba(255,255,255,0.2);}
#mra-list{margin:4px 0;max-height:100px;overflow-y:auto;padding-right:4px;}
#mra-list::-webkit-scrollbar{width:4px}
#mra-list::-webkit-scrollbar-track{background:rgba(0,0,0,0.2);border-radius:2px;}
#mra-list::-webkit-scrollbar-thumb{background:rgba(255,255,255,0.2);border-radius:2px}
#mra-list::-webkit-scrollbar-thumb:hover{background:rgba(255,255,255,0.3);}
#mra-divider{border:none;border-top:1px solid rgba(255,255,255,0.1);margin:6px 0}
#mra-progress-wrap{height:6px;background:rgba(0,0,0,0.5);border-radius:3px;margin:8px 0;overflow:hidden;border:1px solid rgba(255,255,255,0.05);}
#mra-progress-bar{height:100%;background:linear-gradient(90deg, #E52E2E, #ff6b6b);width:0%;transition:width .3s ease-out;border-radius:3px;box-shadow:0 0 10px rgba(229,46,46,0.5);}
#mra-progress-label{color:#888;font-size:10px;text-align:right;margin-bottom:4px}
#mra-status{font-size:11px;color:#ccc;min-height:16px;word-break:break-word;line-height:1.4;text-align:center;padding:6px;background:rgba(0,0,0,0.2);border-radius:6px;border:1px solid rgba(255,255,255,0.05);}
@keyframes mra-pulse-red{0%,100%{box-shadow:0 0 5px rgba(229,46,46,0.2);border-color:rgba(229,46,46,0.3)}50%{box-shadow:0 0 15px rgba(229,46,46,0.8);border-color:rgba(229,46,46,0.8)}}
@keyframes mra-pulse-yellow{0%,100%{box-shadow:0 0 5px rgba(251,191,36,0.2);border-color:rgba(251,191,36,0.3)}50%{box-shadow:0 0 15px rgba(251,191,36,0.8);border-color:rgba(251,191,36,0.8)}}
.mra-pulse-red{animation:mra-pulse-red 2s ease-in-out infinite}
.mra-pulse-yellow{animation:mra-pulse-yellow 2.5s ease-in-out infinite}
</style>

<div id="mra-header">
  <div id="mra-title"><span style="background:#E52E2E;color:#fff;padding:2px 6px;border-radius:4px;margin-right:8px;box-shadow:0 0 10px rgba(229,46,46,0.5);">ТСН</span> АВТОРЕКЛАМА</div>
  <div style="display:flex;align-items:center;gap:6px">
    <button id="mra-reload" title="Перезапустити розширення (Очистити дані)">↻</button>
    <button id="mra-minimize" title="Згорнути">−</button>
    <button id="mra-close" title="Закрити панель">✕</button>
  </div>
</div>

<div id="mra-body">

  <div class="ms">
    <div class="mst">📊 Основне</div>
    <div style="color:#ffffff;font-size:11px;padding:4px 0;font-weight:600;opacity:0.9;text-align:center;">
      🫠 Авто-режим
      <div style="margin-top:4px;font-weight:400;opacity:0.8;">ставимо рекламу скільки можна через 1.5-2 хв</div>
    </div>
    <div style="margin-top:8px;">
      <div class="mtw">
        <label class="mt"><input type="checkbox" id="mra-focus-start" checked><span class="msl"></span></label>
        <span class="mtl" style="color:#ffffff;opacity:0.85;font-weight:500;">🎯 Більше реклами на початку (x2 буст)</span>
      </div>
      <div class="mtw" style="margin-top:6px;">
        <label class="mt"><input type="checkbox" id="mra-auto-open" checked><span class="msl"></span></label>
        <span class="mtl">🔄 Автоматично відкривати панель</span>
      </div>
      <div class="mtw" style="margin-top:6px;">
        <label class="mt"><input type="checkbox" id="mra-autosave" checked><span class="msl"></span></label>
        <span class="mtl">💾 Автозбереження (Продовжити + Зберегти)</span>
      </div>
    </div>
  </div>

  <div class="ms">
    <div class="mst">🔇 Де ставити рекламу</div>
    ${row('Мін. пауза для реклами (с):', stepper('mra-min-silence', 1.5, 0.1, 30, 0.1), 'БОТ СТАВИТЬ РЕКЛАМУ ЛИШЕ ТАМ, ДЕ Є ПАУЗА ДОВША ЗА N СЕКУНД!\nМісця з коротшою тишею — ПРОПУСКАЮТЬСЯ. Рекомендовано: 1.5-3 сек')}
    ${row('Чутливість до тиші (%):', stepper('mra-threshold', 15, 1, 50, 1), '↑ більше % = бот бачить менше пауз (тільки дуже тихі місця)\n↓ менше % = бот бачить більше пауз (навіть напівтиші)')}
  </div>

  <div class="ms">
    <div class="mst">↔️ Відстань між рекламами</div>
    <div class="mtw">
      <label class="mt"><input type="checkbox" id="mra-auto-gap" checked><span class="msl"></span></label>
      <span class="mtl" title="Бот сам підбирає частоту реклами залежно від довжини відео">🤖 Авто (бот вирішує сам)</span>
    </div>
    <div id="mra-auto-sect">
      ${row('Короткі відео — до (хв):', stepper('mra-cutoff', 10, 1, 120, 1), 'Відео коротше цього = "коротке". Наприклад: 10 хв → відео до 10 хв вважаються короткими')}
      ${row('Реклама кожні (с) — короткі:', stepper('mra-short-gap', 60, 1, 600, 1), 'Для коротких відео: ставити рекламу кожні N секунд')}
      ${row('Реклама кожні (с) — довгі:', stepper('mra-long-gap', 120, 1, 3600, 1), 'Для довгих відео: ставити рекламу кожні N секунд')}
    </div>
    <div id="mra-manual-sect" style="display:none">
      ${row('Мінімум між рекламами (с):', stepper('mra-min-gap', 120, 1, 7200, 1), 'Ручний режим: не ставити дві реклами ближче, ніж вказана кількість секунд')}
    </div>
  </div>

  <button id="mra-analyze">🔴 Аналізувати паузи</button>

  <div class="ms" id="mra-waveform-section" style="display:none;">
    <div class="mst">🕵🏻 Вейвформа<br><span style="color:#888;text-transform:none;font-size:9.5px;font-weight:400;margin-top:2px;display:block;">(те, що бачить ваш віртуальний колега ВАЛЕРА)</span></div>
    <canvas id="mra-waveform" width="282" height="80" style="width:100%;border:1px solid #333;border-radius:6px;cursor:crosshair;background:#1a1a1a;" title="Клік = додати/видалити мітку"></canvas>
    <div style="color:#666;font-size:9px;margin-top:3px;">
      <span style="color:#e60000;">━</span> = авто-паузи |
      <span style="color:#ffffff;">━✋</span> = вручну |
      <span style="color:#ffd166;">- -</span> = поріг |
      <span style="color:#888;">Клік = додати/видалити</span>
    </div>
  </div>

  <div id="mra-stats" style="display:none; padding:8px; margin-bottom:8px; background:#1a1a1a; border-radius:6px; border:1px solid #333; text-align:center; font-size:12px; font-weight:600;"></div>
  <div id="mra-list"></div>
  <hr id="mra-divider">
  <button id="mra-insert" disabled>⚡ Вставити маркери</button>
  <button id="mra-clear">🗑️ Очистити всі мітки на відео</button>
  <div id="mra-progress-label"></div>
  <div id="mra-progress-wrap"><div id="mra-progress-bar"></div></div>
  <div id="mra-status">Готовий до роботи</div>
</div>
  `;

  document.body.appendChild(panel);

  // ── Відновлюємо розміри панелі ──
  chrome.storage.local.get(['mraPanelWidth', 'mraPanelHeight'], (data) => {
    if (data.mraPanelWidth) panel.style.width = data.mraPanelWidth;
    if (data.mraPanelHeight) panel.style.height = data.mraPanelHeight;
  });

  // ── Зберігаємо розміри панелі при розтягуванні ──
  let resizeTimer;
  new ResizeObserver(() => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => {
      if (panel.style.width || panel.style.height) {
        chrome.storage.local.set({
          mraPanelWidth: panel.style.width,
          mraPanelHeight: panel.style.height
        });
      }
    }, 500);
  }).observe(panel);

  // ── Відновлюємо збережені налаштування в UI ──
  _restoreSettingsToUI();

  // ── ГЛОБАЛЬНЕ ЗАХОПЛЕННЯ КЛАВІАТУРИ (з трекінгом для cleanup) ──
  const keyBlocker = (e) => {
    if (e.target && e.target.classList && e.target.classList.contains('stp-v')) {
      e.stopImmediatePropagation();
      e.stopPropagation();
    }
  };
  ['keydown', 'keyup', 'keypress'].forEach(evtType => {
    addTrackedEventListener(window, evtType, keyBlocker, { capture: true });
  });

  // ── Авто-перерахунок при зміні налаштувань ──
  let analyzeTimer = null;
  function triggerAutoAnalyze() {
    clearTimeout(analyzeTimer);
    analyzeTimer = setTimeout(() => {
      readSettings();
      saveSettings();
      if (state.cachedAudioBuffer) {
        analyzeWaveform().catch(e => console.error(e));
      }
    }, 250);
  }

  // ── Прив'язуємо stepper-кнопки (−/+) до всіх контролів ──
  panel.querySelectorAll('.stp').forEach(stp => {
    const valEl = stp.querySelector('.stp-v');
    const minVal = parseFloat(stp.dataset.min);
    const maxVal = parseFloat(stp.dataset.max);
    const step = parseFloat(stp.dataset.step);

    const updateVal = (newValStr) => {
      let next = parseFloat(newValStr);
      if (isNaN(next)) next = parseFloat(stp.dataset.val);
      if (next < minVal) next = minVal;
      if (next > maxVal) next = maxVal;
      valEl.value = Math.round(next * 1000) / 1000;
      triggerAutoAnalyze();
    };

    // ── Швидке прокручування при утриманні кнопки ──
    let holdTimer = null;
    let intervalTimer = null;

    const stopHold = () => {
      clearTimeout(holdTimer);
      clearInterval(intervalTimer);
      holdTimer = null;
      intervalTimer = null;
    };

    const startHold = (isPlus) => {
      stopHold(); // Очищаємо попередні таймери перед зачаттям нового

      const dir = isPlus ? 1 : -1;
      let cur = parseFloat(valEl.value) || parseFloat(stp.dataset.val);
      updateVal(cur + (step * dir));

      holdTimer = setTimeout(() => {
        intervalTimer = setInterval(() => {
          let current = parseFloat(valEl.value) || parseFloat(stp.dataset.val);
          updateVal(current + (step * dir * 5));
        }, 100);
      }, 400);
    };

    const btnM = stp.querySelector('.stp-m');
    const btnP = stp.querySelector('.stp-p');

    const attachPointerEvents = (btn, isPlus) => {
      const onDown = (e) => {
        if (e.button !== 0) return;
        e.preventDefault();
        btn.setPointerCapture(e.pointerId);
        startHold(isPlus);
      };
      const onUp = (e) => {
        btn.releasePointerCapture(e.pointerId);
        stopHold();
      };
      btn.addEventListener('pointerdown', onDown);
      btn.addEventListener('pointerup', onUp);
      btn.addEventListener('pointercancel', stopHold);
      btn.addEventListener('mouseleave', stopHold);
      activeEventListeners.push(
        { element: btn, event: 'pointerdown', handler: onDown, options: false },
        { element: btn, event: 'pointerup', handler: onUp, options: false },
        { element: btn, event: 'pointercancel', handler: stopHold, options: false },
        { element: btn, event: 'mouseleave', handler: stopHold, options: false }
      );
    };

    attachPointerEvents(btnM, false);
    attachPointerEvents(btnP, true);

    // Глобальний fallback
    addTrackedEventListener(window, 'mouseup', stopHold);
    addTrackedEventListener(window, 'touchend', stopHold);

    // Введення через Prompt
    valEl.style.cursor = 'pointer';
    const onValClick = () => {
      const currentVal = valEl.value;
      const newValStr = prompt(`Введіть нове значення (мінімум: ${minVal}, максимум: ${maxVal}):`, currentVal);
      if (newValStr !== null && newValStr.trim() !== '') {
        updateVal(newValStr.replace(',', '.'));
      }
    };
    addTrackedEventListener(valEl, 'click', onValClick);

    // ── Скрол коліщатком ──
    const onWheel = (e) => {
      e.preventDefault();
      e.stopPropagation();
      const cur = parseFloat(valEl.value) || parseFloat(stp.dataset.val);
      if (e.deltaY < 0) updateVal(cur + step);
      else updateVal(cur - step);
    };
    addTrackedEventListener(stp, 'wheel', onWheel, { passive: false });
  });

  // ── Тогл авто-gap ──
  const autoGapCb = document.getElementById('mra-auto-gap');
  autoGapCb.addEventListener('change', () => {
    document.getElementById('mra-auto-sect').style.display = autoGapCb.checked ? '' : 'none';
    document.getElementById('mra-manual-sect').style.display = autoGapCb.checked ? 'none' : '';
    triggerAutoAnalyze();
  });

  const focusStartCb = document.getElementById('mra-focus-start');
  if (focusStartCb) focusStartCb.addEventListener('change', triggerAutoAnalyze);

  const autoOpenCbEvt = document.getElementById('mra-auto-open');
  if (autoOpenCbEvt) {
    autoOpenCbEvt.addEventListener('change', () => {
      CONFIG.autoOpenPanel = autoOpenCbEvt.checked;
      saveSettings();
    });
  }

  const autosaveCbEvt = document.getElementById('mra-autosave');
  if (autosaveCbEvt) {
    autosaveCbEvt.addEventListener('change', () => {
      CONFIG.autoSaveAfterInsert = autosaveCbEvt.checked;
      saveSettings();
    });
  }

  // ── Аналізувати ──
  document.getElementById('mra-analyze').addEventListener('click', async () => {
    updateStatus('⏳ Аналізуємо...', 'info');
    try { await analyzeWaveform(); }
    catch (e) { updateStatus('❌ Помилка: ' + e.message, 'error'); log(e.message, 'error'); }
  });

  // ── Клік по вейвформі для додавання мітки вручну ──
  const waveformCanvas = document.getElementById('mra-waveform');
  if (waveformCanvas) {
    waveformCanvas.addEventListener('click', (e) => {
      if (!state.waveformData) return;

      const rect = waveformCanvas.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const clickPercent = x / rect.width;
      const clickSec = clickPercent * state.waveformData.duration;

      // Перевірити, чи клік близько до існуючої мітки (для видалення)
      const existingIdx = state.selected.findIndex(s => Math.abs(s.seconds - clickSec) < 5);

      if (existingIdx !== -1) {
        state.selected.splice(existingIdx, 1);
        log(`Видалено мітку на ${toTimecode(clickSec)}`, 'warn');
        renderSelectedList();
        renderWaveform();
        return;
      }

      // Шукаємо найближчу реальну паузу в радіусі 15 секунд
      // Якщо пауза не знайдена — НЕ дозволяємо ставити мітку (YouTube все одно відхилить)
      if (!state.silences || state.silences.length === 0) {
        log('❌ Не можна поставити мітку: спочатку виконайте аналіз (немає даних про паузи)', 'error');
        showHud('❌ Спочатку натисніть "Аналізувати"', 'error');
        return;
      }

      let closestSilence = state.silences[0];
      let minDist = Math.abs(closestSilence.seconds - clickSec);

      state.silences.forEach(s => {
        const dist = Math.abs(s.seconds - clickSec);
        if (dist < minDist) {
          minDist = dist;
          closestSilence = s;
        }
      });

      // Немає паузи в радіусі 15с — відхиляємо
      if (minDist > 15) {
        log(`❌ Немає паузи поруч (${toTimecode(clickSec)}). YouTube не дозволить рекламу без реальної паузи тиші.`, 'error');
        showHud(`❌ Немає паузи в ±15с
YouTube відхилить рекламу без тиші`, 'error');
        return;
      }

      const finalSec = closestSilence.seconds;

      // Перевіряємо чи мітка в межах відео
      if (finalSec < 0 || finalSec >= state.waveformData.duration) {
        log(`Таймкод за межами відео: ${toTimecode(finalSec)}`, 'error');
        updateStatus('❌ Таймкод за межами відео', 'error');
        return;
      }

      state.selected.push({
        timecode: toTimecode(finalSec),
        seconds: +finalSec.toFixed(2),
        duration_sec: closestSilence.duration_sec,
        amplitude: closestSilence.amplitude,
        manual: true
      });
      state.selected.sort((a, b) => a.seconds - b.seconds);

      const distStr = minDist < 0.5 ? 'точно' : `±${minDist.toFixed(1)}с`;
      const msg = `🧲 Мітка: ${toTimecode(finalSec)}\n${distStr} від кліку · пауза ${closestSilence.duration_sec?.toFixed(1) || '?'}с`;
      log(msg.replace('\n', ' '), 'success');
      showHud(msg, 'success');
      updateStatus(`✅ Мітка на ${toTimecode(finalSec)}`, 'success');

      renderSelectedList();
      renderWaveform();
    });
  }


  // ── Вставити ──
  document.getElementById('mra-insert').addEventListener('click', insertTimecodes);

  // ── Очистити всі мітки (з YouTube) ──
  document.getElementById('mra-clear').addEventListener('click', async () => {
    updateStatus('🗑️ Очищення міток...', 'info');

    // 1. Знімаємо галочку "Автоматичні рекламні місця", інакше YouTube не дасть видалити свої мітки
    const autoAdsCheckbox = document.querySelector('div[role="checkbox"][aria-label="Автоматичні рекламні місця"]');
    if (autoAdsCheckbox && autoAdsCheckbox.getAttribute('aria-checked') === 'true') {
      log('⚙️ Вимикаємо "Автоматичні рекламні місця" від YouTube...', 'info');
      autoAdsCheckbox.click();
      await sleep(400); // Даємо час React застосувати зміни
    }

    let deleteBtns = getAdBreakDeleteButtons();

    if (deleteBtns.length === 0) {
      log('Не знайдено міток для видалення', 'warn');
      updateStatus('Не знайдено міток', 'warn');
      return;
    }

    const totalToDelete = deleteBtns.length;
    log(`Видаляємо ${totalToDelete} міток з відео...`, 'info');
    let deleted = 0;
    while (true) {
      deleteBtns = getAdBreakDeleteButtons();
      if (deleteBtns.length === 0) break;
      deleteBtns[deleteBtns.length - 1].click();
      deleted++;
      await sleep(150);
      if (deleted > totalToDelete + 10) break; // запобігаємо нескінченному циклу
    }

    updateStatus('🗑️ Всі реклами успішно видалено!', 'success');
  });

  // ── Мінімізувати та Закрити ──
  document.getElementById('mra-minimize').addEventListener('click', () => {
    const body = document.getElementById('mra-body');
    const btn = document.getElementById('mra-minimize');
    const hidden = body.style.display === 'none';
    body.style.display = hidden ? '' : 'none';
    btn.textContent = hidden ? '−' : '+';
  });

  document.getElementById('mra-close').addEventListener('click', () => {
    isPanelClosedByUser = true;
    panel.remove();
    createReopenButton();
  });

  // ── Перезавантаження ──
  document.getElementById('mra-reload').addEventListener('click', () => {
    log('♻️ Перезавантаження розширення та скидання налаштувань...', 'info');
    resetSettings();
    state.cachedAudioBuffer = null;
    state.cachedAudioUrl = null;
    state.waveformData = null;
    state.silences = [];
    state.selected = [];
    offscreenCanvas = null;
    lastRenderSignature = null;
    isPanelClosedByUser = false;
    panel.remove();
    // НЕ викликаємо init(), бо він додасть ще один observer
    // Існуючий observer сам побачить, що панелі нема і перемалює її
  });

  // ── Drag (з трекінгом для cleanup) ──
  let isDragging = false, sx, sy, sl, st;
  document.getElementById('mra-header').addEventListener('mousedown', e => {
    if (e.target.tagName === 'BUTTON') return;
    isDragging = true; sx = e.clientX; sy = e.clientY;
    const r = panel.getBoundingClientRect(); sl = r.left; st = r.top;
    panel.style.right = 'auto';
  });

  const onMouseMove = e => {
    if (!isDragging) return;
    panel.style.left = (sl + e.clientX - sx) + 'px';
    panel.style.top = (st + e.clientY - sy) + 'px';
  };
  const onMouseUp = () => { isDragging = false; };

  addTrackedEventListener(document, 'mousemove', onMouseMove);
  addTrackedEventListener(document, 'mouseup', onMouseUp);
}

function createReopenButton() {
  if (document.getElementById('mra-reopen-btn')) return;
  const btn = document.createElement('button');
  btn.id = 'mra-reopen-btn';
  btn.innerHTML = '⚡ Відкрити ТСН АвтоРеклама';
  btn.style.cssText = `
    position: fixed;
    bottom: 24px;
    right: 24px;
    z-index: 10000;
    background: #e63946;
    color: white;
    border: none;
    border-radius: 8px;
    padding: 12px 24px;
    font-size: 15px;
    font-family: 'YouTube Noto', Roboto, Arial, sans-serif;
    font-weight: 500;
    cursor: pointer;
    box-shadow: 0 4px 12px rgba(0,0,0,0.4);
    transition: 0.2s;
  `;
  btn.onmouseover = () => { btn.style.transform = 'scale(1.05)'; btn.style.background = '#ff4d5a'; };
  btn.onmouseout = () => { btn.style.transform = 'scale(1)'; btn.style.background = '#e63946'; };

  btn.addEventListener('click', () => {
    isPanelClosedByUser = false;
    btn.remove();
    // MutationObserver відразу помітить isPanelClosedByUser = false і створить нову панель
  });

  document.body.appendChild(btn);
}
