// ─── АВТОПРИХОВАННЯ ПАНЕЛІ ─────────────────────────────────────────────────
// Панель ховається коли відкритий модальний діалог YouTube або інший редактор
function isYouTubeDialogOpen() {
    var sels = [
        'ytcp-dialog:not([hidden])',
        '.ytcp-dialog:not([hidden])',
        '.cdk-overlay-container',
        'tp-yt-paper-dialog',
        '.ytcp-confirmation-dialog',
        '[role="dialog"]:not([hidden])'
    ];
    for (var i = 0; i < sels.length; i++) {
        var el = document.querySelector(sels[i]);
        if (el && el.getBoundingClientRect().width > 0 && el.getBoundingClientRect().height > 0) return true;
    }
    if (document.querySelector('.cdk-overlay-backdrop-showing, .ytcp-dialog-backdrop')) return true;
    return false;
}

function isOtherEditorActive() {
    var edSels = [
        '.ytcp-endscreen-editor',
        '.ytcp-cards-editor',
        '.ytcp-music-editor',
        '.ytcp-subtitles-editor',
        'ytve-endscreen-editor',
        'ytve-cards-editor'
    ];
    for (var i = 0; i < edSels.length; i++) {
        var el = document.querySelector(edSels[i]);
        if (el && el.getBoundingClientRect().width > 0) return true;
    }
    return false;
}

var _panelVisTimer = null;
function updatePanelVisibility() {
    clearTimeout(_panelVisTimer);
    _panelVisTimer = setTimeout(function () {
        var p = document.getElementById('mra-panel');
        if (!p || (typeof isPanelClosedByUser !== 'undefined' && isPanelClosedByUser)) return;
        var hide = isYouTubeDialogOpen() || isOtherEditorActive();
        if (hide) {
            p.style.opacity = '0.15';
            p.style.pointerEvents = 'none';
            p.style.visibility = 'hidden';
        } else {
            p.style.opacity = '';
            p.style.pointerEvents = '';
            p.style.visibility = '';
        }
    }, 200);
}